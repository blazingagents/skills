from __future__ import annotations

import mimetypes
import re
from collections.abc import AsyncIterator, Generator, Iterator, Mapping, Sequence
from contextlib import contextmanager
from datetime import datetime
from os import PathLike
from pathlib import Path
from typing import Annotated, Literal, get_args

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, TypeAdapter
from pydantic.alias_generators import to_camel

from ._models import (
    Agent,
    AgentsPage,
    Artifact,
    ArtifactDownloadUrl,
    ArtifactsPage,
    LatestSessionsPage,
    McpAttachment,
    McpAttachments,
    McpConnection,
    McpConnectionReconnectResult,
    McpConnections,
    McpConnectionTestResult,
    MemoriesPage,
    Memory,
    MemoryResponse,
    Prompt,
    PromptsPage,
    Provider,
    ProviderModels,
    Providers,
    Session,
    SessionInputResponse,
    SessionInputsPage,
    SessionMessagesPage,
    SessionResponse,
    SessionsPage,
    SessionStopResponse,
    SessionUsageList,
    Skill,
    SkillCopyResult,
    SkillCopyResults,
    SkillDetail,
    SkillsPage,
    SpendingLimitResponse,
    Task,
    TaskCreateResponse,
    TaskListItem,
    TaskRun,
    TaskRunMessagesPage,
    TaskRunsPage,
    TaskRunSubmission,
    TasksPage,
    TenantSettings,
    ThinkingLevels,
    ToolApprovals,
    Usage,
    UsageOverview,
    Workspace,
    WorkspacesPage,
    _validate_cron,
    _validate_timezone,
)
from ._transport import (
    OMITTED,
    RESPONSE_BYTES,
    RESPONSE_STATUS,
    AsyncTransport,
    SyncTransport,
    _Omitted,
    _Request,
    camel_case_keys,
    drop_omitted,
    path_segment,
)
from ._types import (
    AgentTool,
    ApprovalPolicyInput,
    McpConnectionAuthType,
    ProviderType,
    QuotaUpdate,
    SkillArchiveType,
    SpendingLimitInput,
    TaskScheduleInput,
    Timeout,
    UploadFile,
    UsageGroupBy,
    WorkspaceDeletionOutcome,
    WorkspaceNetworkPolicy,
    WorkspaceTier,
)


def _spending_limit_body(
    spending_limit: SpendingLimitInput | None,
) -> dict[str, object]:
    return {
        "spendingLimit": None
        if spending_limit is None
        else camel_case_keys(spending_limit)
    }


_SkillCopyResultList = list[SkillCopyResult]
_ISO_OFFSET_DATETIME = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)


def _agent_body(
    *,
    name: str | _Omitted,
    model: str | None | _Omitted,
    provider_id: str | None | _Omitted,
    thinking_level: str | None | _Omitted,
    workspace_id: str | _Omitted,
    workspace_tier: WorkspaceTier | _Omitted = OMITTED,
    auto_compaction: bool | _Omitted,
    compaction_reserve_tokens: int | _Omitted,
    memory_injection_enabled: bool | _Omitted,
    tools: Sequence[AgentTool] | _Omitted,
    approval_in_chat: ApprovalPolicyInput | _Omitted,
    approval_in_tasks: ApprovalPolicyInput | _Omitted,
    instructions: str | _Omitted,
    user_id: str | _Omitted,
    metadata: dict[str, object] | _Omitted,
    mcp_connection_ids: Sequence[str] | _Omitted,
) -> dict[str, object]:
    """Build the agent request body, omitting unspecified fields."""
    if not isinstance(workspace_id, _Omitted) and not isinstance(
        workspace_tier, _Omitted
    ):
        raise ValueError("workspace_id and workspace_tier are mutually exclusive")
    body: dict[str, object] = drop_omitted(
        ("name", name),
        ("model", model),
        ("providerId", provider_id),
        ("thinkingLevel", thinking_level),
        ("workspaceId", workspace_id),
        ("workspaceTier", workspace_tier),
        ("autoCompaction", auto_compaction),
        ("compactionReserveTokens", compaction_reserve_tokens),
        ("memoryInjectionEnabled", memory_injection_enabled),
        ("tools", tools),
        ("instructions", instructions),
        ("userId", user_id),
        ("metadata", metadata),
        ("mcpConnectionIds", mcp_connection_ids),
    )
    for wire_name, policy in drop_omitted(
        ("approvalInChat", approval_in_chat),
        ("approvalInTasks", approval_in_tasks),
    ).items():
        body[wire_name] = _approval_policy_body(policy)
    return body


def _approval_policy_body(policy: ApprovalPolicyInput) -> dict[str, object]:
    """Build the approval policy request body, omitting unspecified fields."""
    body: dict[str, object] = {"default": policy["default"]}
    if "overrides" in policy:
        body["overrides"] = [
            {"tool": camel_case_keys(rule["tool"]), "decision": rule["decision"]}
            for rule in policy["overrides"]
        ]
    return body


def _validate_agent_create_configuration(
    model: object,
    provider_id: str | None | _Omitted,
) -> None:
    """Require provider_id and model together when configuring an Agent."""
    if isinstance(model, _Omitted) and isinstance(provider_id, _Omitted):
        return
    if (
        isinstance(model, _Omitted)
        or isinstance(provider_id, _Omitted)
        or model is None
        or provider_id is None
    ):
        msg = "provider_id and model must both be provided"
        raise ValueError(msg)


def _validate_agent_update_configuration(
    model: str | None | _Omitted,
    provider_id: str | None | _Omitted,
) -> None:
    """Validate provider changes and paired null configuration values."""
    if not isinstance(provider_id, _Omitted) and isinstance(model, _Omitted):
        msg = "Changing provider_id requires model"
        raise ValueError(msg)
    if not isinstance(model, _Omitted) and (
        (model is None and provider_id is not None)
        or (model is not None and provider_id is None)
    ):
        msg = "provider_id and model must both be null when clearing"
        raise ValueError(msg)


def _agent_path(agent_id: str) -> str:
    """Build the encoded agent endpoint path."""
    return f"/v1/agents/{path_segment('agent_id', agent_id)}"


def _sessions_path(agent_id: str, session_id: str | None = None) -> str:
    """Build the encoded sessions endpoint path."""
    path = f"/v1/agents/{path_segment('agent_id', agent_id)}/sessions"
    if session_id is not None:
        return f"{path}/{path_segment('session_id', session_id)}"
    return path


def _inputs_body(
    request_id: str,
    message: Mapping[str, object],
) -> dict[str, object]:
    """Build the inputs request body, omitting unspecified fields."""
    path_segment("request_id", request_id)
    body: dict[str, object] = {"requestId": request_id, "message": message}
    return body


def _inputs_query(
    include_completed: bool | _Omitted,
    cursor: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the inputs query, omitting unspecified filters."""
    query: dict[str, str | int] = {}
    if not isinstance(include_completed, _Omitted):
        query["includeCompleted"] = str(include_completed).lower()
    return query | drop_omitted(("cursor", cursor), ("limit", limit))


def _sessions_query(
    user_id: str | _Omitted,
    cursor: str | _Omitted,
    limit: int | _Omitted,
    by_agent: bool | None = None,
) -> dict[str, str | int]:
    """Build the sessions query, omitting unspecified filters."""
    query: dict[str, str | int] = drop_omitted(
        ("userId", user_id),
        ("cursor", cursor),
        ("limit", limit),
    )
    if by_agent is not None:
        query["byAgent"] = str(by_agent).lower()
    return query


def _session_messages_query(
    cursor: str | _Omitted,
    after: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the session messages query, omitting unspecified filters."""
    query: dict[str, str | int] = drop_omitted(
        ("cursor", cursor),
        ("after", after),
        ("limit", limit),
    )
    return query


def _task_path(task_id: str | None = None) -> str:
    """Build the encoded task endpoint path."""
    path = "/v1/tasks"
    if task_id is None:
        return path
    return f"{path}/{path_segment('task_id', task_id)}"


def _task_run_path(task_id: str, run_id: str | None = None) -> str:
    """Build the encoded task run endpoint path."""
    path = f"{_task_path(task_id)}/runs"
    if run_id is None:
        return path
    return f"{path}/{path_segment('run_id', run_id)}"


def _validate_offset_datetime(value: str) -> str:
    """Return an ISO datetime with a timezone offset, or raise ValueError."""
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        parsed = None
    if (
        _ISO_OFFSET_DATETIME.fullmatch(value) is None
        or parsed is None
        or parsed.utcoffset() is None
    ):
        msg = "once schedule at must be an ISO datetime with an offset"
        raise ValueError(msg)
    return value


class _WireInput(BaseModel):
    """Caller input validated by its snake_case names, sent with camelCase names."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        extra="forbid",
        strict=True,
        validate_by_name=True,
        validate_by_alias=False,
    )


class _TaskOnceConfigInput(_WireInput):
    at: Annotated[str, AfterValidator(_validate_offset_datetime)]


class _TaskIntervalConfigInput(_WireInput):
    every_ms: int = Field(ge=60_000)


class _TaskCronConfigInput(_WireInput):
    expression: Annotated[str, AfterValidator(_validate_cron)]
    timezone: Annotated[str, AfterValidator(_validate_timezone)] | None = None
    stagger_ms: int | None = Field(default=None, ge=0)


class _TaskOnceScheduleInput(_WireInput):
    kind: Literal["once"]
    config: _TaskOnceConfigInput


class _TaskIntervalScheduleInput(_WireInput):
    kind: Literal["interval"]
    config: _TaskIntervalConfigInput


class _TaskCronScheduleInput(_WireInput):
    kind: Literal["cron"]
    config: _TaskCronConfigInput


_TASK_SCHEDULE: TypeAdapter[
    _TaskOnceScheduleInput | _TaskIntervalScheduleInput | _TaskCronScheduleInput
] = TypeAdapter(
    Annotated[
        _TaskOnceScheduleInput | _TaskIntervalScheduleInput | _TaskCronScheduleInput,
        Field(discriminator="kind"),
    ],
    config=ConfigDict(title="schedule"),
)


def _task_schedule(schedule: TaskScheduleInput) -> dict[str, object]:
    """Validate a one-time, interval, or cron Task schedule into its wire shape."""
    return _TASK_SCHEDULE.validate_python(schedule).model_dump(
        by_alias=True, exclude_none=True
    )


def _task_body(
    *,
    agent_id: str | _Omitted,
    name: str | _Omitted,
    prompt: str | _Omitted,
    schedule: TaskScheduleInput | None | _Omitted,
    enabled: bool | _Omitted,
    submit: bool | _Omitted,
    user_id: str | _Omitted,
    metadata: dict[str, object] | _Omitted,
    idempotency_key: str | _Omitted,
) -> dict[str, object]:
    """Build the task request body, omitting unspecified fields."""
    body: dict[str, object] = _task_run_body(idempotency_key)
    body |= drop_omitted(
        ("agentId", agent_id),
        ("name", name),
        ("prompt", prompt),
        ("enabled", enabled),
        ("submit", submit),
        ("userId", user_id),
        ("metadata", metadata),
    )
    if not isinstance(schedule, _Omitted):
        body["schedule"] = None if schedule is None else _task_schedule(schedule)
    return body


def _tasks_query(
    agent_id: str | _Omitted,
    user_id: str | _Omitted,
    cursor: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the tasks query, omitting unspecified filters."""
    return drop_omitted(
        ("agentId", agent_id),
        ("userId", user_id),
        ("cursor", cursor),
        ("limit", limit),
    )


def _task_run_body(
    idempotency_key: str | _Omitted,
) -> dict[str, object]:
    """Build the task run request body, omitting unspecified fields."""
    if isinstance(idempotency_key, _Omitted):
        return {}
    if not isinstance(idempotency_key, str):
        msg = "idempotency_key must be a string"
        raise TypeError(msg)
    if not idempotency_key.strip():
        msg = "idempotency_key must not be blank"
        raise ValueError(msg)
    return {"idempotencyKey": idempotency_key}


def _agents_query(
    user_id: str | _Omitted,
    workspace_id: str | _Omitted,
) -> dict[str, str]:
    """Build the agents query, omitting unspecified filters."""
    return drop_omitted(
        ("userId", user_id),
        ("workspaceId", workspace_id),
    )


def _cursor_limit_query(
    cursor: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the cursor limit query, omitting unspecified filters."""
    return drop_omitted(("cursor", cursor), ("limit", limit))


def _workspace_path(workspace_id: str) -> str:
    """Build the encoded workspace endpoint path."""
    return f"/v1/workspaces/{path_segment('workspace_id', workspace_id)}"


def _workspace_body(
    *,
    name: str | None | _Omitted,
    user_id: str | _Omitted,
    metadata: dict[str, object] | _Omitted,
    network_policy: WorkspaceNetworkPolicy | _Omitted,
    tier: WorkspaceTier | _Omitted = OMITTED,
) -> dict[str, object]:
    """Build the workspace request body, omitting unspecified fields."""
    return drop_omitted(
        ("name", name),
        ("tier", tier),
        ("userId", user_id),
        ("metadata", metadata),
        (
            "networkPolicy",
            network_policy
            if isinstance(network_policy, _Omitted)
            else camel_case_keys(network_policy),
        ),
    )


def _workspaces_query(
    cursor: str | _Omitted,
    limit: int | _Omitted,
    user_id: str | _Omitted,
) -> dict[str, str | int]:
    """Build the workspaces query, omitting unspecified filters."""
    return drop_omitted(
        ("cursor", cursor),
        ("limit", limit),
        ("userId", user_id),
    )


def _mcp_attachment_body(
    forward_user_id: bool | _Omitted,
    forwarded_metadata_keys: Sequence[str] | _Omitted,
) -> dict[str, object]:
    """Build the mcp attachment request body, omitting unspecified fields."""
    body: dict[str, object] = drop_omitted(
        ("forwardUserId", forward_user_id),
        ("forwardedMetadataKeys", forwarded_metadata_keys),
    )
    if not body:
        msg = "At least one MCP Attachment field must be provided."
        raise ValueError(msg)
    return body


def _provider_body(
    *,
    provider_type: ProviderType,
    api_key: str,
    model: str | _Omitted,
    name: str | _Omitted,
    base_url: str | None | _Omitted,
) -> dict[str, object]:
    """Build the provider request body, omitting unspecified fields."""
    if provider_type not in get_args(ProviderType):
        msg = "provider_type must be a supported Provider type"
        raise ValueError(msg)
    if provider_type == "custom" and (isinstance(base_url, _Omitted) or not base_url):
        msg = "base_url is required for custom Providers"
        raise ValueError(msg)
    if (
        provider_type == "vercel_ai_gateway"
        and not isinstance(base_url, _Omitted)
        and base_url is not None
    ):
        msg = "base_url is not accepted for Vercel AI Gateway Providers"
        raise ValueError(msg)
    body: dict[str, object] = {
        "providerType": provider_type,
        "apiKey": api_key,
    }
    body |= drop_omitted(
        ("name", name),
        ("baseUrl", base_url),
        ("model", model),
    )
    return body


def _provider_update_body(
    name: str | _Omitted,
) -> dict[str, object]:
    """Build the provider update request body, omitting unspecified fields."""
    body: dict[str, object] = {} if isinstance(name, _Omitted) else {"name": name}
    if not body:
        msg = "At least one Provider field must be provided."
        raise ValueError(msg)
    return body


def _provider_path(provider_id: str) -> str:
    """Build the encoded provider endpoint path."""
    return f"/v1/providers/{path_segment('provider_id', provider_id)}"


def _mcp_connection_path(mcp_connection_id: str) -> str:
    """Build the encoded mcp connection endpoint path."""
    return f"/v1/mcp-connections/{path_segment('mcp_connection_id', mcp_connection_id)}"


def _prompt_path(prompt_id: str) -> str:
    """Build the encoded prompt endpoint path."""
    return f"/v1/prompts/{path_segment('prompt_id', prompt_id)}"


def _memory_path(agent_id: str, memory_id: str | None = None) -> str:
    """Build the encoded memory endpoint path."""
    path = f"{_agent_path(agent_id)}/memories"
    if memory_id is None:
        return path
    return f"{path}/{path_segment('memory_id', memory_id)}"


def _skill_path(agent_id: str, skill_id: str | None = None) -> str:
    """Build the encoded skill endpoint path."""
    path = f"{_agent_path(agent_id)}/skills"
    if skill_id is None:
        return path
    return f"{path}/{path_segment('skill_id', skill_id)}"


def _artifact_path(artifact_id: str) -> str:
    """Build the encoded artifact endpoint path."""
    return f"/v1/artifacts/{path_segment('artifact_id', artifact_id)}"


def _artifacts_query(
    agent_id: str | _Omitted,
    session_id: str | _Omitted,
    cursor: str | _Omitted,
) -> dict[str, str]:
    """Build the artifacts query, omitting unspecified filters."""
    return drop_omitted(
        ("agentId", agent_id),
        ("sessionId", session_id),
        ("cursor", cursor),
    )


def _skills_query(
    cursor: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the skills query, omitting unspecified filters."""
    return drop_omitted(("cursor", cursor), ("limit", limit))


def _memory_body(
    *,
    text: str,
    user_id: str | _Omitted,
) -> dict[str, object]:
    """Build the memory request body, omitting unspecified fields."""
    body: dict[str, object] = {"text": text}
    return body | drop_omitted(("userId", user_id))


def _memories_query(
    *,
    user_id: str | _Omitted,
    search: str | _Omitted,
    cursor: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the memories query, omitting unspecified filters."""
    return drop_omitted(
        ("userId", user_id),
        ("search", search),
        ("cursor", cursor),
        ("limit", limit),
    )


def _prompt_body(
    *,
    name: str | _Omitted,
    template: str | _Omitted,
    agent_id: str | None | _Omitted,
    user_id: str | _Omitted,
    metadata: dict[str, object] | _Omitted,
) -> dict[str, object]:
    """Build the prompt request body, omitting unspecified fields."""
    return drop_omitted(
        ("name", name),
        ("template", template),
        ("agentId", agent_id),
        ("userId", user_id),
        ("metadata", metadata),
    )


def _mcp_connection_body(
    *,
    auth_type: McpConnectionAuthType,
    url: str,
    name: str | _Omitted,
    bearer_token: str | _Omitted,
    client_id: str | _Omitted,
    client_secret: str | _Omitted,
    scope: str | _Omitted,
) -> dict[str, object]:
    """Build the mcp connection request body, omitting unspecified fields."""
    if auth_type not in get_args(McpConnectionAuthType):
        msg = "auth_type must be a supported MCP Connection authentication type"
        raise ValueError(msg)

    supplied = {
        "bearer": not isinstance(bearer_token, _Omitted),
        "client_id": not isinstance(client_id, _Omitted),
        "client_secret": not isinstance(client_secret, _Omitted),
        "scope": not isinstance(scope, _Omitted),
    }
    if auth_type == "none" and any(supplied.values()):
        msg = "none authentication accepts exactly no credential fields"
        raise ValueError(msg)
    if auth_type == "bearer" and (
        not supplied["bearer"]
        or supplied["client_id"]
        or supplied["client_secret"]
        or supplied["scope"]
    ):
        msg = "bearer authentication accepts exactly bearer_token"
        raise ValueError(msg)
    if auth_type == "oauth_authorization_code":
        if supplied["bearer"]:
            msg = "Authorization Code does not accept bearer_token"
            raise ValueError(msg)
        if supplied["client_id"] != supplied["client_secret"]:
            msg = "client_id and client_secret must be provided together"
            raise ValueError(msg)
    if auth_type == "oauth_client_credentials" and (
        supplied["bearer"] or not supplied["client_id"] or not supplied["client_secret"]
    ):
        msg = "OAuth Client Credentials requires exactly client_id and client_secret"
        raise ValueError(msg)

    body: dict[str, object] = {"authType": auth_type, "url": url}
    body |= drop_omitted(
        ("name", name),
        ("bearerToken", bearer_token),
        ("clientId", client_id),
        ("clientSecret", client_secret),
        ("scope", scope),
    )
    return body


def _credential_values(*values: str | _Omitted) -> tuple[str, ...]:
    """Collect credential values for response redaction."""
    return tuple(value for value in values if isinstance(value, str) and value)


@contextmanager
def _upload_part(
    file: UploadFile,
    *,
    filename: str | None,
    content_type: str | None,
    fallback_filename: str | None = None,
) -> Generator[dict[str, tuple[str, object, str]]]:
    """Open or normalize an upload part and close owned file handles."""
    opened = None
    source_name: str | None = None
    if isinstance(file, bytes):
        content: object = file
    elif isinstance(file, (str, PathLike)):
        path = Path(file)
        opened = path.open("rb")
        content = opened
        source_name = path.name
    else:
        content = file
        raw_name = getattr(file, "name", None)
        if isinstance(raw_name, str):
            source_name = Path(raw_name).name

    upload_name = filename or source_name or fallback_filename
    if not upload_name:
        msg = "filename is required for bytes and unnamed file objects"
        raise ValueError(msg)
    upload_type = content_type or mimetypes.guess_type(upload_name)[0]
    try:
        yield {
            "file": (
                upload_name,
                content,
                upload_type or "application/octet-stream",
            )
        }
    finally:
        if opened is not None:
            opened.close()


@contextmanager
def _skill_upload_request(
    *,
    agent_id: str,
    archive_type: SkillArchiveType,
    file: UploadFile,
    filename: str | None,
    extra_headers: Mapping[str, str] | None,
    timeout: Timeout | _Omitted,
) -> Generator[_Request]:
    """Build a multipart Skill upload request."""
    if archive_type not in get_args(SkillArchiveType):
        msg = "archive_type must be zip, tar, or tar.gz"
        raise ValueError(msg)
    with _upload_part(
        file,
        filename=filename,
        content_type=None,
        fallback_filename=f"skill.{archive_type}",
    ) as file_part:
        multipart: dict[str, object] = {
            "type": (None, archive_type),
            **file_part,
        }
        yield _Request(
            "POST",
            f"{_skill_path(agent_id)}/upload",
            files=multipart,
            extra_headers=extra_headers,
            timeout=timeout,
        )


class UserAgentsResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Agent operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        name: str,
        model: str | _Omitted = OMITTED,
        provider_id: str | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        workspace_tier: WorkspaceTier | _Omitted = OMITTED,
        thinking_level: str | None | _Omitted = OMITTED,
        auto_compaction: bool | _Omitted = OMITTED,
        compaction_reserve_tokens: int | _Omitted = OMITTED,
        memory_injection_enabled: bool | _Omitted = OMITTED,
        tools: list[AgentTool] | _Omitted = OMITTED,
        approval_in_chat: ApprovalPolicyInput | _Omitted = OMITTED,
        approval_in_tasks: ApprovalPolicyInput | _Omitted = OMITTED,
        instructions: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        mcp_connection_ids: list[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Create an Agent.

        Omitted fields retain server defaults or existing values.

        Args:
            name: Agent display name, 1 to 80 characters.
            model: Provider model identifier.
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            workspace_id: Workspace identifier.
            workspace_tier: Tier for an automatic Workspace; defaults to Core.
                Mutually exclusive with workspace_id.
            thinking_level: Provider-supported reasoning level.
            auto_compaction: Whether the Agent compacts its context automatically.
            compaction_reserve_tokens: Tokens reserved for context compaction.
            memory_injection_enabled: Whether the Agent injects matching Memories.
            tools: Built-in tools available to the Agent.
            approval_in_chat: Tool approval policy for chat Turns.
            approval_in_tasks: Tool approval policy for Task Turns.
            instructions: Agent instructions.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            mcp_connection_ids: MCP Connections attached to the Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: provider_id and model are not both supplied when configuring
                an Agent.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        _validate_agent_create_configuration(model, provider_id)
        return self._transport.request(
            _Request(
                "POST",
                "/v1/agents",
                json_body=_agent_body(
                    name=name,
                    model=model,
                    provider_id=provider_id,
                    workspace_id=workspace_id,
                    workspace_tier=workspace_tier,
                    thinking_level=thinking_level,
                    auto_compaction=auto_compaction,
                    compaction_reserve_tokens=compaction_reserve_tokens,
                    memory_injection_enabled=memory_injection_enabled,
                    tools=tools,
                    approval_in_chat=approval_in_chat,
                    approval_in_tasks=approval_in_tasks,
                    instructions=instructions,
                    user_id=user_id,
                    metadata=metadata,
                    mcp_connection_ids=mcp_connection_ids,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AgentsPage:
        """Fetch one page of Agent records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/agents",
                query={
                    **_agents_query(user_id, workspace_id),
                    **_cursor_limit_query(cursor, limit),
                },
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            AgentsPage,
        )

    def get(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Fetch the requested Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _agent_path(agent_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    def list_mcp_attachments(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpAttachments:
        """Fetch MCP attachments for an Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            MCP attachments for the Agent.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_agent_path(agent_id)}/mcp-attachments",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpAttachments,
        )

    def update_mcp_attachment(
        self,
        agent_id: str,
        mcp_connection_id: str,
        *,
        forward_user_id: bool | _Omitted = OMITTED,
        forwarded_metadata_keys: Sequence[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpAttachment:
        """Update an Agent MCP attachment.

        Args:
            agent_id: Agent identifier.
            mcp_connection_id: MCP Connection identifier.
            forward_user_id: Whether to forward the user identifier to this MCP
                Connection.
            forwarded_metadata_keys: Metadata keys to forward to this MCP Connection.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Updated MCP attachment settings.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "PATCH",
                (
                    f"{_agent_path(agent_id)}/mcp-attachments/"
                    f"{path_segment('mcp_connection_id', mcp_connection_id)}"
                ),
                json_body=_mcp_attachment_body(
                    forward_user_id,
                    forwarded_metadata_keys,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpAttachment,
        )

    def update(
        self,
        agent_id: str,
        *,
        name: str | _Omitted = OMITTED,
        model: str | None | _Omitted = OMITTED,
        provider_id: str | None | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        thinking_level: str | None | _Omitted = OMITTED,
        auto_compaction: bool | _Omitted = OMITTED,
        compaction_reserve_tokens: int | _Omitted = OMITTED,
        memory_injection_enabled: bool | _Omitted = OMITTED,
        tools: Sequence[AgentTool] | _Omitted = OMITTED,
        approval_in_chat: ApprovalPolicyInput | _Omitted = OMITTED,
        approval_in_tasks: ApprovalPolicyInput | _Omitted = OMITTED,
        instructions: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        mcp_connection_ids: Sequence[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Update the provided Agent fields.

        Omitted fields retain server defaults or existing values. Changing
        provider_id requires model. Set both to None to clear them.

        Args:
            agent_id: Agent identifier.
            name: Agent display name, 1 to 80 characters.
            model: Provider model identifier.
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            workspace_id: Workspace identifier.
            thinking_level: Provider-supported reasoning level. None clears the
                setting. Omission retains the current value.
            auto_compaction: Whether the Agent compacts its context automatically.
            compaction_reserve_tokens: Tokens reserved for context compaction.
            memory_injection_enabled: Whether the Agent injects matching Memories.
            tools: Built-in tools available to the Agent.
            approval_in_chat: Tool approval policy for chat Turns.
            approval_in_tasks: Tool approval policy for Task Turns.
            instructions: Agent instructions.
            metadata: Caller-defined JSON metadata.
            mcp_connection_ids: MCP Connections attached to the Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: Provider and model changes are inconsistent.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        _validate_agent_update_configuration(model, provider_id)
        body = _agent_body(
            name=name,
            model=model,
            provider_id=provider_id,
            workspace_id=workspace_id,
            thinking_level=thinking_level,
            auto_compaction=auto_compaction,
            compaction_reserve_tokens=compaction_reserve_tokens,
            memory_injection_enabled=memory_injection_enabled,
            tools=tools,
            approval_in_chat=approval_in_chat,
            approval_in_tasks=approval_in_tasks,
            instructions=instructions,
            user_id=OMITTED,
            metadata=metadata,
            mcp_connection_ids=mcp_connection_ids,
        )
        if not body:
            msg = "At least one agent field must be provided."
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "PUT",
                _agent_path(agent_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    def disable(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Disable the Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_agent_path(agent_id)}/disable",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    def enable(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Enable the Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_agent_path(agent_id)}/enable",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    def delete(
        self,
        agent_id: str,
        *,
        include_artifacts: bool,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Agent.

        Args:
            agent_id: Agent identifier.
            include_artifacts: Whether to include the Agent Artifacts in deletion.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _agent_path(agent_id),
                query={"includeArtifacts": str(include_artifacts).lower()},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    def upload_avatar(
        self,
        agent_id: str,
        file: UploadFile,
        *,
        filename: str | None = None,
        content_type: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Upload an Agent avatar.

        Paths are opened and closed by the SDK. Caller-owned file objects remain
        open.

        Args:
            agent_id: Agent identifier.
            file: File upload input.
            filename: Filename supplied for the upload.
            content_type: Media type for the upload.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: No filename is available for bytes or an unnamed file object.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        with _upload_part(
            file,
            filename=filename,
            content_type=content_type,
        ) as files:
            return self._transport.request(
                _Request(
                    "POST",
                    f"{_agent_path(agent_id)}/avatar",
                    files=files,
                    extra_headers=extra_headers,
                    timeout=timeout,
                ),
                Agent,
            )

    def remove_avatar(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Remove an Agent avatar.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                f"{_agent_path(agent_id)}/avatar",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )


class AgentsResource(UserAgentsResource):
    def get_spending_limit(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Fetch the Agent model spending limit using tenant authority."""
        return self._transport.request(
            _Request(
                "GET",
                _agent_path(agent_id) + "/spending-limit",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    def update_spending_limit(
        self,
        agent_id: str,
        *,
        spending_limit: SpendingLimitInput | None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Set or disable the Agent model spending limit using tenant authority."""
        return self._transport.request(
            _Request(
                "PUT",
                _agent_path(agent_id) + "/spending-limit",
                json_body=_spending_limit_body(spending_limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )


class AsyncUserAgentsResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Agent operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        name: str,
        model: str | _Omitted = OMITTED,
        provider_id: str | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        workspace_tier: WorkspaceTier | _Omitted = OMITTED,
        thinking_level: str | None | _Omitted = OMITTED,
        auto_compaction: bool | _Omitted = OMITTED,
        compaction_reserve_tokens: int | _Omitted = OMITTED,
        memory_injection_enabled: bool | _Omitted = OMITTED,
        tools: list[AgentTool] | _Omitted = OMITTED,
        approval_in_chat: ApprovalPolicyInput | _Omitted = OMITTED,
        approval_in_tasks: ApprovalPolicyInput | _Omitted = OMITTED,
        instructions: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        mcp_connection_ids: list[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Create an Agent.

        Omitted fields retain server defaults or existing values.

        Args:
            name: Agent display name, 1 to 80 characters.
            model: Provider model identifier.
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            workspace_id: Workspace identifier.
            workspace_tier: Tier for an automatic Workspace; defaults to Core.
                Mutually exclusive with workspace_id.
            thinking_level: Provider-supported reasoning level.
            auto_compaction: Whether the Agent compacts its context automatically.
            compaction_reserve_tokens: Tokens reserved for context compaction.
            memory_injection_enabled: Whether the Agent injects matching Memories.
            tools: Built-in tools available to the Agent.
            approval_in_chat: Tool approval policy for chat Turns.
            approval_in_tasks: Tool approval policy for Task Turns.
            instructions: Agent instructions.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            mcp_connection_ids: MCP Connections attached to the Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: provider_id and model are not both supplied when configuring
                an Agent.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        _validate_agent_create_configuration(model, provider_id)
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/agents",
                json_body=_agent_body(
                    name=name,
                    model=model,
                    provider_id=provider_id,
                    workspace_id=workspace_id,
                    workspace_tier=workspace_tier,
                    thinking_level=thinking_level,
                    auto_compaction=auto_compaction,
                    compaction_reserve_tokens=compaction_reserve_tokens,
                    memory_injection_enabled=memory_injection_enabled,
                    tools=tools,
                    approval_in_chat=approval_in_chat,
                    approval_in_tasks=approval_in_tasks,
                    instructions=instructions,
                    user_id=user_id,
                    metadata=metadata,
                    mcp_connection_ids=mcp_connection_ids,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    async def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AgentsPage:
        """Fetch one page of Agent records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/agents",
                query={
                    **_agents_query(user_id, workspace_id),
                    **_cursor_limit_query(cursor, limit),
                },
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            AgentsPage,
        )

    async def get(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Fetch the requested Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _agent_path(agent_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    async def list_mcp_attachments(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpAttachments:
        """Fetch MCP attachments for an Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            MCP attachments for the Agent.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_agent_path(agent_id)}/mcp-attachments",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpAttachments,
        )

    async def update_mcp_attachment(
        self,
        agent_id: str,
        mcp_connection_id: str,
        *,
        forward_user_id: bool | _Omitted = OMITTED,
        forwarded_metadata_keys: Sequence[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpAttachment:
        """Update an Agent MCP attachment.

        Args:
            agent_id: Agent identifier.
            mcp_connection_id: MCP Connection identifier.
            forward_user_id: Whether to forward the user identifier to this MCP
                Connection.
            forwarded_metadata_keys: Metadata keys to forward to this MCP Connection.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Updated MCP attachment settings.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "PATCH",
                (
                    f"{_agent_path(agent_id)}/mcp-attachments/"
                    f"{path_segment('mcp_connection_id', mcp_connection_id)}"
                ),
                json_body=_mcp_attachment_body(
                    forward_user_id,
                    forwarded_metadata_keys,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpAttachment,
        )

    async def update(
        self,
        agent_id: str,
        *,
        name: str | _Omitted = OMITTED,
        model: str | None | _Omitted = OMITTED,
        provider_id: str | None | _Omitted = OMITTED,
        workspace_id: str | _Omitted = OMITTED,
        thinking_level: str | None | _Omitted = OMITTED,
        auto_compaction: bool | _Omitted = OMITTED,
        compaction_reserve_tokens: int | _Omitted = OMITTED,
        memory_injection_enabled: bool | _Omitted = OMITTED,
        tools: Sequence[AgentTool] | _Omitted = OMITTED,
        approval_in_chat: ApprovalPolicyInput | _Omitted = OMITTED,
        approval_in_tasks: ApprovalPolicyInput | _Omitted = OMITTED,
        instructions: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        mcp_connection_ids: Sequence[str] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Update the provided Agent fields.

        Omitted fields retain server defaults or existing values. Changing
        provider_id requires model. Set both to None to clear them.

        Args:
            agent_id: Agent identifier.
            name: Agent display name, 1 to 80 characters.
            model: Provider model identifier.
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            workspace_id: Workspace identifier.
            thinking_level: Provider-supported reasoning level. None clears the
                setting. Omission retains the current value.
            auto_compaction: Whether the Agent compacts its context automatically.
            compaction_reserve_tokens: Tokens reserved for context compaction.
            memory_injection_enabled: Whether the Agent injects matching Memories.
            tools: Built-in tools available to the Agent.
            approval_in_chat: Tool approval policy for chat Turns.
            approval_in_tasks: Tool approval policy for Task Turns.
            instructions: Agent instructions.
            metadata: Caller-defined JSON metadata.
            mcp_connection_ids: MCP Connections attached to the Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: Provider and model changes are inconsistent.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        _validate_agent_update_configuration(model, provider_id)
        body = _agent_body(
            name=name,
            model=model,
            provider_id=provider_id,
            workspace_id=workspace_id,
            thinking_level=thinking_level,
            auto_compaction=auto_compaction,
            compaction_reserve_tokens=compaction_reserve_tokens,
            memory_injection_enabled=memory_injection_enabled,
            tools=tools,
            approval_in_chat=approval_in_chat,
            approval_in_tasks=approval_in_tasks,
            instructions=instructions,
            user_id=OMITTED,
            metadata=metadata,
            mcp_connection_ids=mcp_connection_ids,
        )
        if not body:
            msg = "At least one agent field must be provided."
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "PUT",
                _agent_path(agent_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    async def disable(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Disable the Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_agent_path(agent_id)}/disable",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    async def enable(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Enable the Agent.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_agent_path(agent_id)}/enable",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )

    async def delete(
        self,
        agent_id: str,
        *,
        include_artifacts: bool,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Agent.

        Args:
            agent_id: Agent identifier.
            include_artifacts: Whether to include the Agent Artifacts in deletion.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _agent_path(agent_id),
                query={"includeArtifacts": str(include_artifacts).lower()},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    async def upload_avatar(
        self,
        agent_id: str,
        file: UploadFile,
        *,
        filename: str | None = None,
        content_type: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Upload an Agent avatar.

        Paths are opened and closed by the SDK. Caller-owned file objects remain
        open.

        Args:
            agent_id: Agent identifier.
            file: File upload input.
            filename: Filename supplied for the upload.
            content_type: Media type for the upload.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            ValueError: No filename is available for bytes or an unnamed file object.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        with _upload_part(
            file,
            filename=filename,
            content_type=content_type,
        ) as files:
            return await self._transport.request(
                _Request(
                    "POST",
                    f"{_agent_path(agent_id)}/avatar",
                    files=files,
                    extra_headers=extra_headers,
                    timeout=timeout,
                ),
                Agent,
            )

    async def remove_avatar(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Agent:
        """Remove an Agent avatar.

        Args:
            agent_id: Agent identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Agent details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                f"{_agent_path(agent_id)}/avatar",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Agent,
        )


class AsyncAgentsResource(AsyncUserAgentsResource):
    async def get_spending_limit(
        self,
        agent_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Fetch the Agent model spending limit using tenant authority."""
        return await self._transport.request(
            _Request(
                "GET",
                _agent_path(agent_id) + "/spending-limit",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    async def update_spending_limit(
        self,
        agent_id: str,
        *,
        spending_limit: SpendingLimitInput | None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Set or disable the Agent model spending limit using tenant authority."""
        return await self._transport.request(
            _Request(
                "PUT",
                _agent_path(agent_id) + "/spending-limit",
                json_body=_spending_limit_body(spending_limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )


class ProvidersResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Provider operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        name: str,
        provider_type: ProviderType,
        api_key: str,
        base_url: str | None | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Create a Provider.

        Args:
            name: Provider display name, unique within the tenant.
            provider_type: Provider API type.
            api_key: The vendor API key. It is stored encrypted, never returned,
                and cannot be changed later.
            base_url: Endpoint override. Required for custom, not accepted for
                vercel_ai_gateway, and optional otherwise. Cannot be changed later.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                "/v1/providers",
                json_body=_provider_body(
                    provider_type=provider_type,
                    api_key=api_key,
                    model=OMITTED,
                    name=name,
                    base_url=base_url,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=(api_key,),
            ),
            Provider,
        )

    def list(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Providers:
        """Fetch one page of Provider records.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Available Providers.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/providers",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Providers,
        )

    def get(
        self,
        provider_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Fetch the requested Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _provider_path(provider_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Provider,
        )

    def list_models(
        self,
        provider_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ProviderModels:
        """Fetch available models for a Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Models advertised by the Provider.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_provider_path(provider_id)}/models",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ProviderModels,
        )

    def get_thinking_levels(
        self,
        provider_id: str,
        *,
        model: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ThinkingLevels:
        """Fetch supported thinking levels for a model.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            model: Provider model identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Thinking levels supported by the selected model.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_provider_path(provider_id)}/thinking-levels",
                query={"model": model},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ThinkingLevels,
        )

    def update(
        self,
        provider_id: str,
        *,
        name: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Update the provided Provider fields.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            name: Provider display name, unique within the tenant.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "PATCH",
                _provider_path(provider_id),
                json_body=_provider_update_body(name),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Provider,
        )

    def delete(
        self,
        provider_id: str,
        *,
        confirm_snapshot_invalidation: bool = False,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            confirm_snapshot_invalidation: Explicit consent to invalidate dependent
                snapshots.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _provider_path(provider_id),
                query=(
                    {"confirmSnapshotInvalidation": "true"}
                    if confirm_snapshot_invalidation
                    else {}
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncProvidersResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Provider operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        name: str,
        provider_type: ProviderType,
        api_key: str,
        base_url: str | None | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Create a Provider.

        Args:
            name: Provider display name, unique within the tenant.
            provider_type: Provider API type.
            api_key: The vendor API key. It is stored encrypted, never returned,
                and cannot be changed later.
            base_url: Endpoint override. Required for custom, not accepted for
                vercel_ai_gateway, and optional otherwise. Cannot be changed later.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/providers",
                json_body=_provider_body(
                    provider_type=provider_type,
                    api_key=api_key,
                    model=OMITTED,
                    name=name,
                    base_url=base_url,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=(api_key,),
            ),
            Provider,
        )

    async def list(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Providers:
        """Fetch one page of Provider records.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Available Providers.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/providers",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Providers,
        )

    async def get(
        self,
        provider_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Fetch the requested Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _provider_path(provider_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Provider,
        )

    async def list_models(
        self,
        provider_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ProviderModels:
        """Fetch available models for a Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Models advertised by the Provider.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_provider_path(provider_id)}/models",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ProviderModels,
        )

    async def get_thinking_levels(
        self,
        provider_id: str,
        *,
        model: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ThinkingLevels:
        """Fetch supported thinking levels for a model.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            model: Provider model identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Thinking levels supported by the selected model.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_provider_path(provider_id)}/thinking-levels",
                query={"model": model},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ThinkingLevels,
        )

    async def update(
        self,
        provider_id: str,
        *,
        name: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Provider:
        """Update the provided Provider fields.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            name: Provider display name, unique within the tenant.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Provider details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "PATCH",
                _provider_path(provider_id),
                json_body=_provider_update_body(name),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Provider,
        )

    async def delete(
        self,
        provider_id: str,
        *,
        confirm_snapshot_invalidation: bool = False,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Provider.

        Args:
            provider_id: Provider identifier. Supply with model when configuring an
                Agent.
            confirm_snapshot_invalidation: Explicit consent to invalidate dependent
                snapshots.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _provider_path(provider_id),
                query=(
                    {"confirmSnapshotInvalidation": "true"}
                    if confirm_snapshot_invalidation
                    else {}
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class McpConnectionsResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind MCP Connection operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        name: str,
        url: str,
        auth_type: McpConnectionAuthType,
        bearer_token: str | _Omitted = OMITTED,
        client_id: str | _Omitted = OMITTED,
        client_secret: str | _Omitted = OMITTED,
        scope: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Create a MCP Connection.

        Bearer authentication accepts only bearer_token. OAuth client credentials
        require client_id and client_secret. Authorization code credentials must be
        paired.

        Args:
            name: MCP Connection display name, unique within the tenant.
            url: Service endpoint URL.
            auth_type: Connection authentication type.
            bearer_token: Bearer token for bearer authentication.
            client_id: OAuth client identifier.
            client_secret: OAuth client secret.
            scope: OAuth scopes requested from the MCP service.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            ValueError: The authentication type and supplied credential fields do not
                match.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _mcp_connection_body(
            auth_type=auth_type,
            url=url,
            name=name,
            bearer_token=bearer_token,
            client_id=client_id,
            client_secret=client_secret,
            scope=scope,
        )
        return self._transport.request(
            _Request(
                "POST",
                "/v1/mcp-connections",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=_credential_values(
                    bearer_token,
                    client_secret,
                ),
            ),
            McpConnection,
        )

    def list(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnections:
        """Fetch one page of MCP Connection records.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Available MCP Connections.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/mcp-connections",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnections,
        )

    def get(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Fetch the requested MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _mcp_connection_path(mcp_connection_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnection,
        )

    def update(
        self,
        mcp_connection_id: str,
        *,
        name: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Update the provided MCP Connection fields.

        Args:
            mcp_connection_id: MCP Connection identifier.
            name: MCP Connection display name, unique within the tenant.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        if isinstance(name, _Omitted):
            msg = "At least one MCP Connection field must be provided."
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "PATCH",
                _mcp_connection_path(mcp_connection_id),
                json_body={"name": name},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnection,
        )

    def delete(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _mcp_connection_path(mcp_connection_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    def test(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnectionTestResult:
        """Test an MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Connectivity test result.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_mcp_connection_path(mcp_connection_id)}/test",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnectionTestResult,
        )

    def reconnect(
        self,
        mcp_connection_id: str,
        *,
        url: str,
        auth_type: McpConnectionAuthType,
        bearer_token: str | _Omitted = OMITTED,
        client_id: str | _Omitted = OMITTED,
        client_secret: str | _Omitted = OMITTED,
        scope: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnectionReconnectResult:
        """Reconnect an MCP Connection.

        Bearer authentication accepts only bearer_token. OAuth client credentials
        require client_id and client_secret. Authorization code credentials must be
        paired.

        Args:
            mcp_connection_id: MCP Connection identifier.
            url: Service endpoint URL.
            auth_type: Connection authentication type.
            bearer_token: Bearer token for bearer authentication.
            client_id: OAuth client identifier.
            client_secret: OAuth client secret.
            scope: OAuth scopes requested from the MCP service.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Result of the reconnect request.

        Raises:
            ValueError: The authentication type and supplied credential fields do not
                match.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _mcp_connection_body(
            auth_type=auth_type,
            url=url,
            name=OMITTED,
            bearer_token=bearer_token,
            client_id=client_id,
            client_secret=client_secret,
            scope=scope,
        )
        return self._transport.request(
            _Request(
                "POST",
                f"{_mcp_connection_path(mcp_connection_id)}/reconnect",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=_credential_values(
                    bearer_token,
                    client_secret,
                ),
            ),
            McpConnectionReconnectResult,
        )


class AsyncMcpConnectionsResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind MCP Connection operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        name: str,
        url: str,
        auth_type: McpConnectionAuthType,
        bearer_token: str | _Omitted = OMITTED,
        client_id: str | _Omitted = OMITTED,
        client_secret: str | _Omitted = OMITTED,
        scope: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Create a MCP Connection.

        Bearer authentication accepts only bearer_token. OAuth client credentials
        require client_id and client_secret. Authorization code credentials must be
        paired.

        Args:
            name: MCP Connection display name, unique within the tenant.
            url: Service endpoint URL.
            auth_type: Connection authentication type.
            bearer_token: Bearer token for bearer authentication.
            client_id: OAuth client identifier.
            client_secret: OAuth client secret.
            scope: OAuth scopes requested from the MCP service.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            ValueError: The authentication type and supplied credential fields do not
                match.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _mcp_connection_body(
            auth_type=auth_type,
            url=url,
            name=name,
            bearer_token=bearer_token,
            client_id=client_id,
            client_secret=client_secret,
            scope=scope,
        )
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/mcp-connections",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=_credential_values(
                    bearer_token,
                    client_secret,
                ),
            ),
            McpConnection,
        )

    async def list(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnections:
        """Fetch one page of MCP Connection records.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Available MCP Connections.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/mcp-connections",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnections,
        )

    async def get(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Fetch the requested MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _mcp_connection_path(mcp_connection_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnection,
        )

    async def update(
        self,
        mcp_connection_id: str,
        *,
        name: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnection:
        """Update the provided MCP Connection fields.

        Args:
            mcp_connection_id: MCP Connection identifier.
            name: MCP Connection display name, unique within the tenant.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested MCP Connection details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        if isinstance(name, _Omitted):
            msg = "At least one MCP Connection field must be provided."
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "PATCH",
                _mcp_connection_path(mcp_connection_id),
                json_body={"name": name},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnection,
        )

    async def delete(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _mcp_connection_path(mcp_connection_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    async def test(
        self,
        mcp_connection_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnectionTestResult:
        """Test an MCP Connection.

        Args:
            mcp_connection_id: MCP Connection identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Connectivity test result.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_mcp_connection_path(mcp_connection_id)}/test",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            McpConnectionTestResult,
        )

    async def reconnect(
        self,
        mcp_connection_id: str,
        *,
        url: str,
        auth_type: McpConnectionAuthType,
        bearer_token: str | _Omitted = OMITTED,
        client_id: str | _Omitted = OMITTED,
        client_secret: str | _Omitted = OMITTED,
        scope: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> McpConnectionReconnectResult:
        """Reconnect an MCP Connection.

        Bearer authentication accepts only bearer_token. OAuth client credentials
        require client_id and client_secret. Authorization code credentials must be
        paired.

        Args:
            mcp_connection_id: MCP Connection identifier.
            url: Service endpoint URL.
            auth_type: Connection authentication type.
            bearer_token: Bearer token for bearer authentication.
            client_id: OAuth client identifier.
            client_secret: OAuth client secret.
            scope: OAuth scopes requested from the MCP service.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Result of the reconnect request.

        Raises:
            ValueError: The authentication type and supplied credential fields do not
                match.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _mcp_connection_body(
            auth_type=auth_type,
            url=url,
            name=OMITTED,
            bearer_token=bearer_token,
            client_id=client_id,
            client_secret=client_secret,
            scope=scope,
        )
        return await self._transport.request(
            _Request(
                "POST",
                f"{_mcp_connection_path(mcp_connection_id)}/reconnect",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
                sensitive_values=_credential_values(
                    bearer_token,
                    client_secret,
                ),
            ),
            McpConnectionReconnectResult,
        )


class MemoriesResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Memory operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        agent_id: str,
        text: str,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Create a Memory.

        Args:
            agent_id: Agent identifier.
            text: Memory text to store.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                _memory_path(agent_id),
                json_body=_memory_body(text=text, user_id=user_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    def list(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        search: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoriesPage:
        """Fetch one page of Memory records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            search: Search filter sent to the API.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _memory_path(agent_id),
                query=_memories_query(
                    user_id=user_id,
                    search=search,
                    cursor=cursor,
                    limit=limit,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoriesPage,
        )

    def iter(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        search: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[Memory]:
        """Iterate Memory records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            search: Search filter sent to the API.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Memory records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                agent_id=agent_id,
                user_id=user_id,
                search=search,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def get(
        self,
        *,
        agent_id: str,
        memory_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Fetch the requested Memory.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _memory_path(agent_id, memory_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    def update(
        self,
        *,
        agent_id: str,
        memory_id: str,
        text: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Update the provided Memory fields.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            text: Memory text to store.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "PATCH",
                _memory_path(agent_id, memory_id),
                json_body={"text": text},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    def delete(
        self,
        *,
        agent_id: str,
        memory_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Memory.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _memory_path(agent_id, memory_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncMemoriesResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Memory operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        agent_id: str,
        text: str,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Create a Memory.

        Args:
            agent_id: Agent identifier.
            text: Memory text to store.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                _memory_path(agent_id),
                json_body=_memory_body(text=text, user_id=user_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    async def list(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        search: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoriesPage:
        """Fetch one page of Memory records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            search: Search filter sent to the API.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _memory_path(agent_id),
                query=_memories_query(
                    user_id=user_id,
                    search=search,
                    cursor=cursor,
                    limit=limit,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoriesPage,
        )

    async def iter(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        search: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[Memory]:
        """Iterate Memory records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            search: Search filter sent to the API.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Memory records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                agent_id=agent_id,
                user_id=user_id,
                search=search,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for memory in page.data:
                yield memory
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def get(
        self,
        *,
        agent_id: str,
        memory_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Fetch the requested Memory.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _memory_path(agent_id, memory_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    async def update(
        self,
        *,
        agent_id: str,
        memory_id: str,
        text: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> MemoryResponse:
        """Update the provided Memory fields.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            text: Memory text to store.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Memory response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "PATCH",
                _memory_path(agent_id, memory_id),
                json_body={"text": text},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            MemoryResponse,
        )

    async def delete(
        self,
        *,
        agent_id: str,
        memory_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Memory.

        Args:
            agent_id: Agent identifier.
            memory_id: Memory identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _memory_path(agent_id, memory_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class PromptsResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Prompt operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        name: str,
        template: str,
        agent_id: str | None | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Create a Prompt.

        Args:
            name: Prompt display name, 1 to 80 characters.
            template: Prompt template text.
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                "/v1/prompts",
                json_body=_prompt_body(
                    name=name,
                    template=template,
                    agent_id=agent_id,
                    user_id=user_id,
                    metadata=metadata,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> PromptsPage:
        """Fetch one page of Prompt records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/prompts",
                query=drop_omitted(("userId", user_id), ("agentId", agent_id))
                | _cursor_limit_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            PromptsPage,
        )

    def get(
        self,
        *,
        prompt_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Fetch the requested Prompt.

        Args:
            prompt_id: Stored Prompt identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _prompt_path(prompt_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    def update(
        self,
        *,
        prompt_id: str,
        agent_id: str | None | _Omitted = OMITTED,
        name: str | _Omitted = OMITTED,
        template: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Update the provided Prompt fields.

        Args:
            prompt_id: Stored Prompt identifier.
            agent_id: Agent identifier.
            name: Prompt display name, 1 to 80 characters.
            template: Prompt template text.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _prompt_body(
            name=name,
            template=template,
            agent_id=agent_id,
            user_id=OMITTED,
            metadata=metadata,
        )
        if not body:
            msg = "At least one Prompt field must be provided."
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "PATCH",
                _prompt_path(prompt_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    def delete(
        self,
        *,
        prompt_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Prompt.

        Args:
            prompt_id: Stored Prompt identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _prompt_path(prompt_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncPromptsResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Prompt operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        name: str,
        template: str,
        agent_id: str | None | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Create a Prompt.

        Args:
            name: Prompt display name, 1 to 80 characters.
            template: Prompt template text.
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/prompts",
                json_body=_prompt_body(
                    name=name,
                    template=template,
                    agent_id=agent_id,
                    user_id=user_id,
                    metadata=metadata,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    async def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> PromptsPage:
        """Fetch one page of Prompt records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/prompts",
                query=drop_omitted(("userId", user_id), ("agentId", agent_id))
                | _cursor_limit_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            PromptsPage,
        )

    async def get(
        self,
        *,
        prompt_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Fetch the requested Prompt.

        Args:
            prompt_id: Stored Prompt identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _prompt_path(prompt_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    async def update(
        self,
        *,
        prompt_id: str,
        agent_id: str | None | _Omitted = OMITTED,
        name: str | _Omitted = OMITTED,
        template: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Prompt:
        """Update the provided Prompt fields.

        Args:
            prompt_id: Stored Prompt identifier.
            agent_id: Agent identifier.
            name: Prompt display name, 1 to 80 characters.
            template: Prompt template text.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Prompt details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _prompt_body(
            name=name,
            template=template,
            agent_id=agent_id,
            user_id=OMITTED,
            metadata=metadata,
        )
        if not body:
            msg = "At least one Prompt field must be provided."
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "PATCH",
                _prompt_path(prompt_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Prompt,
        )

    async def delete(
        self,
        *,
        prompt_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Prompt.

        Args:
            prompt_id: Stored Prompt identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _prompt_path(prompt_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class WorkspacesResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Workspace operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        tier: WorkspaceTier | _Omitted = OMITTED,
        name: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        network_policy: WorkspaceNetworkPolicy | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Create a Workspace.

        Args:
            tier: Immutable Workspace tier; defaults to Core.
            name: Workspace display name, up to 80 characters.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            network_policy: Workspace network access policy.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                "/v1/workspaces",
                json_body=_workspace_body(
                    tier=tier,
                    name=name,
                    user_id=user_id,
                    metadata=metadata,
                    network_policy=network_policy,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> WorkspacesPage:
        """Fetch one page of Workspace records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/workspaces",
                query=_workspaces_query(cursor, limit, user_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            WorkspacesPage,
        )

    def iter(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[Workspace]:
        """Iterate Workspace records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Workspace records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                cursor=next_cursor,
                limit=limit,
                user_id=user_id,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def get(
        self,
        *,
        workspace_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Fetch the requested Workspace.

        Args:
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _workspace_path(workspace_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    def update(
        self,
        *,
        workspace_id: str,
        name: str | None | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        network_policy: WorkspaceNetworkPolicy | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Update the provided Workspace fields.

        Args:
            workspace_id: Workspace identifier.
            name: New Workspace display name, or None to clear it.
            metadata: Caller-defined JSON metadata.
            network_policy: Workspace network access policy.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _workspace_body(
            name=name,
            user_id=OMITTED,
            metadata=metadata,
            network_policy=network_policy,
        )
        if not body:
            msg = "At least one Workspace field must be provided."
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "PUT",
                _workspace_path(workspace_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    def delete(
        self,
        *,
        workspace_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> WorkspaceDeletionOutcome:
        """Delete the requested Workspace.

        Args:
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Outcome of the Workspace deletion.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        status = self._transport.request(
            _Request(
                "DELETE",
                _workspace_path(workspace_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            RESPONSE_STATUS,
        )
        return "pending" if status == 202 else "completed"


class AsyncWorkspacesResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Workspace operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        tier: WorkspaceTier | _Omitted = OMITTED,
        name: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        network_policy: WorkspaceNetworkPolicy | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Create a Workspace.

        Args:
            tier: Immutable Workspace tier; defaults to Core.
            name: Workspace display name, up to 80 characters.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            network_policy: Workspace network access policy.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/workspaces",
                json_body=_workspace_body(
                    tier=tier,
                    name=name,
                    user_id=user_id,
                    metadata=metadata,
                    network_policy=network_policy,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    async def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> WorkspacesPage:
        """Fetch one page of Workspace records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/workspaces",
                query=_workspaces_query(cursor, limit, user_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            WorkspacesPage,
        )

    async def iter(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[Workspace]:
        """Iterate Workspace records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            user_id: Caller-defined user identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Workspace records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                cursor=next_cursor,
                limit=limit,
                user_id=user_id,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for workspace in page.data:
                yield workspace
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def get(
        self,
        *,
        workspace_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Fetch the requested Workspace.

        Args:
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _workspace_path(workspace_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    async def update(
        self,
        *,
        workspace_id: str,
        name: str | None | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        network_policy: WorkspaceNetworkPolicy | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Workspace:
        """Update the provided Workspace fields.

        Args:
            workspace_id: Workspace identifier.
            name: New Workspace display name, or None to clear it.
            metadata: Caller-defined JSON metadata.
            network_policy: Workspace network access policy.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Workspace details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _workspace_body(
            name=name,
            user_id=OMITTED,
            metadata=metadata,
            network_policy=network_policy,
        )
        if not body:
            msg = "At least one Workspace field must be provided."
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "PUT",
                _workspace_path(workspace_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Workspace,
        )

    async def delete(
        self,
        *,
        workspace_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> WorkspaceDeletionOutcome:
        """Delete the requested Workspace.

        Args:
            workspace_id: Workspace identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Outcome of the Workspace deletion.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        status = await self._transport.request(
            _Request(
                "DELETE",
                _workspace_path(workspace_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            RESPONSE_STATUS,
        )
        return "pending" if status == 202 else "completed"


class _QuotaInput(_WireInput):
    monthly_token_limit: int | None
    monthly_request_limit: int | None
    reset_day: int


def _tenant_body(
    name: str | _Omitted,
    quota: QuotaUpdate | None | _Omitted,
    monetization_enabled: bool | _Omitted,
) -> dict[str, object]:
    """Build the tenant request body, omitting unspecified fields."""
    body: dict[str, object] = drop_omitted(
        ("name", name), ("monetizationEnabled", monetization_enabled)
    )
    if not isinstance(quota, _Omitted):
        body["quota"] = (
            None
            if quota is None
            else _QuotaInput.model_validate(quota).model_dump(by_alias=True)
        )
    if not body:
        msg = "At least one tenant field must be provided."
        raise ValueError(msg)
    return body


def _usage_query(
    *,
    from_: str | _Omitted,
    to: str | _Omitted,
    agent_id: str | _Omitted,
    session_id: str | _Omitted,
    user_id: str | _Omitted,
    group_by: UsageGroupBy | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the usage query, omitting unspecified filters."""
    query: dict[str, str | int] = drop_omitted(
        ("from", from_),
        ("to", to),
        ("agentId", agent_id),
        ("sessionId", session_id),
        ("userId", user_id),
        ("groupBy", group_by),
        ("limit", limit),
    )
    return query


def _usage_overview_query(
    *,
    from_: str | _Omitted,
    to: str | _Omitted,
    limit: int | _Omitted,
) -> dict[str, str | int]:
    """Build the usage overview query, omitting unspecified filters."""
    query: dict[str, str | int] = drop_omitted(
        ("from", from_), ("to", to), ("limit", limit)
    )
    return query


class TenantResource:
    def get_spending_limit(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Fetch the tenant model spending limit using tenant authority."""
        return self._transport.request(
            _Request(
                "GET",
                "/v1/tenant/spending-limit",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    def update_spending_limit(
        self,
        *,
        spending_limit: SpendingLimitInput | None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Set or disable the tenant model spending limit using tenant authority."""
        return self._transport.request(
            _Request(
                "PUT",
                "/v1/tenant/spending-limit",
                json_body=_spending_limit_body(spending_limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    def __init__(self, transport: SyncTransport) -> None:
        """Bind Tenant settings operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def get(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TenantSettings:
        """Fetch the requested Tenant settings.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Tenant settings and quota limits.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/tenant",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TenantSettings,
        )

    def update(
        self,
        *,
        name: str | _Omitted = OMITTED,
        quota: QuotaUpdate | _Omitted | None = OMITTED,
        monetization_enabled: bool | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TenantSettings:
        """Update the provided Tenant settings fields.

        Args:
            name: Tenant display name, 1 to 80 characters.
            quota: Tenant usage limit updates.
            monetization_enabled: Bill usage to your end users through your
                merchant account. Turning it off drops usage events the merchant
                has not accepted yet.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Tenant settings and quota limits.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "PATCH",
                "/v1/tenant",
                json_body=_tenant_body(name, quota, monetization_enabled),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TenantSettings,
        )


class AsyncTenantResource:
    async def get_spending_limit(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Fetch the tenant model spending limit using tenant authority."""
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/tenant/spending-limit",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    async def update_spending_limit(
        self,
        *,
        spending_limit: SpendingLimitInput | None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SpendingLimitResponse:
        """Set or disable the tenant model spending limit using tenant authority."""
        return await self._transport.request(
            _Request(
                "PUT",
                "/v1/tenant/spending-limit",
                json_body=_spending_limit_body(spending_limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SpendingLimitResponse,
        )

    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Tenant settings operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def get(
        self,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TenantSettings:
        """Fetch the requested Tenant settings.

        Args:
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Tenant settings and quota limits.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/tenant",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TenantSettings,
        )

    async def update(
        self,
        *,
        name: str | _Omitted = OMITTED,
        quota: QuotaUpdate | _Omitted | None = OMITTED,
        monetization_enabled: bool | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TenantSettings:
        """Update the provided Tenant settings fields.

        Args:
            name: Tenant display name, 1 to 80 characters.
            quota: Tenant usage limit updates.
            monetization_enabled: Bill usage to your end users through your
                merchant account. Turning it off drops usage events the merchant
                has not accepted yet.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Tenant settings and quota limits.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "PATCH",
                "/v1/tenant",
                json_body=_tenant_body(name, quota, monetization_enabled),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TenantSettings,
        )


class UserUsageResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind usage operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def get(
        self,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        group_by: UsageGroupBy | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Usage:
        """Fetch the requested usage.

        Args:
            from_: Start of the usage interval.
            to: End of the usage interval.
            agent_id: Agent identifier.
            session_id: Session identifier.
            user_id: Caller-defined user identifier.
            group_by: Dimension used to group usage totals.
            limit: Maximum number of grouped results returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals grouped as requested.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        query = _usage_query(
            from_=from_,
            to=to,
            agent_id=agent_id,
            session_id=session_id,
            user_id=user_id,
            group_by=group_by,
            limit=limit,
        )
        return self._transport.request(
            _Request(
                "GET",
                "/v1/usage",
                query=query,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Usage,
        )

    def sessions(
        self,
        session_ids: Sequence[str],
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionUsageList:
        """Fetch usage totals for up to 100 Sessions.

        Args:
            session_ids: Unique Session identifiers, 1 to 100.
            from_: First UTC day (YYYY-MM-DD) of the usage interval.
            to: Last UTC day (YYYY-MM-DD) of the usage interval.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals for each requested Session.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body: dict[str, object] = {"sessionIds": list(session_ids)}
        body |= drop_omitted(("from", from_), ("to", to))
        return self._transport.request(
            _Request(
                "POST",
                "/v1/usage/sessions",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionUsageList,
        )

    def get_for_agent(
        self,
        agent_id: str,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        group_by: UsageGroupBy | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Usage:
        """Fetch usage for one Agent.

        Args:
            agent_id: Agent identifier.
            from_: Start of the usage interval.
            to: End of the usage interval.
            session_id: Session identifier.
            user_id: Caller-defined user identifier.
            group_by: Dimension used to group usage totals.
            limit: Maximum number of grouped results returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals grouped as requested.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        query = _usage_query(
            from_=from_,
            to=to,
            agent_id=OMITTED,
            session_id=session_id,
            user_id=user_id,
            group_by=group_by,
            limit=limit,
        )
        return self._transport.request(
            _Request(
                "GET",
                f"/v1/agents/{path_segment('agent_id', agent_id)}/usage",
                query=query,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Usage,
        )


class UsageResource(UserUsageResource):
    def overview(
        self,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> UsageOverview:
        """Fetch the usage overview.

        Args:
            from_: Start of the usage interval.
            to: End of the usage interval.
            limit: Maximum number of overview entries returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage overview for the requested interval.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/usage/overview",
                query=_usage_overview_query(from_=from_, to=to, limit=limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            UsageOverview,
        )


class AsyncUserUsageResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind usage operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def get(
        self,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        group_by: UsageGroupBy | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Usage:
        """Fetch the requested usage.

        Args:
            from_: Start of the usage interval.
            to: End of the usage interval.
            agent_id: Agent identifier.
            session_id: Session identifier.
            user_id: Caller-defined user identifier.
            group_by: Dimension used to group usage totals.
            limit: Maximum number of grouped results returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals grouped as requested.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        query = _usage_query(
            from_=from_,
            to=to,
            agent_id=agent_id,
            session_id=session_id,
            user_id=user_id,
            group_by=group_by,
            limit=limit,
        )
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/usage",
                query=query,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Usage,
        )

    async def sessions(
        self,
        session_ids: Sequence[str],
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionUsageList:
        """Fetch usage totals for up to 100 Sessions.

        Args:
            session_ids: Unique Session identifiers, 1 to 100.
            from_: First UTC day (YYYY-MM-DD) of the usage interval.
            to: Last UTC day (YYYY-MM-DD) of the usage interval.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals for each requested Session.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body: dict[str, object] = {"sessionIds": list(session_ids)}
        body |= drop_omitted(("from", from_), ("to", to))
        return await self._transport.request(
            _Request(
                "POST",
                "/v1/usage/sessions",
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionUsageList,
        )

    async def get_for_agent(
        self,
        agent_id: str,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        group_by: UsageGroupBy | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Usage:
        """Fetch usage for one Agent.

        Args:
            agent_id: Agent identifier.
            from_: Start of the usage interval.
            to: End of the usage interval.
            session_id: Session identifier.
            user_id: Caller-defined user identifier.
            group_by: Dimension used to group usage totals.
            limit: Maximum number of grouped results returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage totals grouped as requested.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        query = _usage_query(
            from_=from_,
            to=to,
            agent_id=OMITTED,
            session_id=session_id,
            user_id=user_id,
            group_by=group_by,
            limit=limit,
        )
        return await self._transport.request(
            _Request(
                "GET",
                f"/v1/agents/{path_segment('agent_id', agent_id)}/usage",
                query=query,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Usage,
        )


class AsyncUsageResource(AsyncUserUsageResource):
    async def overview(
        self,
        *,
        from_: str | _Omitted = OMITTED,
        to: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> UsageOverview:
        """Fetch the usage overview.

        Args:
            from_: Start of the usage interval.
            to: End of the usage interval.
            limit: Maximum number of overview entries returned.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Usage overview for the requested interval.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/usage/overview",
                query=_usage_overview_query(from_=from_, to=to, limit=limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            UsageOverview,
        )


class ArtifactsResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Artifact operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def list(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ArtifactsPage:
        """Fetch one page of Artifact records.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/artifacts",
                query=_artifacts_query(agent_id, session_id, cursor),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ArtifactsPage,
        )

    def iter(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[Artifact]:
        """Iterate Artifact records across all pages.

        Pages are fetched lazily until the API returns no continuation cursor.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Artifact records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                agent_id=agent_id,
                session_id=session_id,
                cursor=next_cursor,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def create_download_url(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ArtifactDownloadUrl:
        """Create an expiring Artifact download URL.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Expiring URL for downloading the Artifact.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_artifact_path(artifact_id)}/download-url",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ArtifactDownloadUrl,
        )

    def get(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Artifact:
        """Fetch the requested Artifact.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Artifact details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _artifact_path(artifact_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Artifact,
        )

    def delete(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Artifact.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _artifact_path(artifact_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class TasksResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Task operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def create(
        self,
        *,
        agent_id: str,
        name: str,
        prompt: str,
        schedule: TaskScheduleInput | None | _Omitted = OMITTED,
        enabled: bool | _Omitted = OMITTED,
        submit: bool | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        idempotency_key: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskCreateResponse:
        """Create a Task.

        Args:
            agent_id: Agent identifier.
            name: Task display name, 1 to 80 characters.
            prompt: Task prompt text.
            schedule: One-time, interval, or cron schedule. Intervals use
                every_ms of at least 60000. Cron timezone is optional.
                None clears the schedule. Omission leaves it unset.
            enabled: Whether the Task is enabled.
            submit: Optional initial Task Run submission.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            idempotency_key: Stable key for retrying the same create without
                creating another Task.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Created Task and any submitted initial Run.

        Raises:
            TypeError: The schedule structure or field types are invalid.
            ValueError: The Task schedule, offset datetime, cron expression, or
                timezone is invalid.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                _task_path(),
                json_body=_task_body(
                    agent_id=agent_id,
                    name=name,
                    prompt=prompt,
                    schedule=schedule,
                    enabled=enabled,
                    submit=submit,
                    user_id=user_id,
                    metadata=metadata,
                    idempotency_key=idempotency_key,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskCreateResponse,
        )

    def list(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TasksPage:
        """Fetch one page of Task records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _task_path(),
                query=_tasks_query(agent_id, user_id, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TasksPage,
        )

    def iter(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[TaskListItem]:
        """Iterate Task records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            TaskListItem records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                agent_id=agent_id,
                user_id=user_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def get(
        self,
        task_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Task:
        """Fetch the requested Task.

        Args:
            task_id: Task identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _task_path(task_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Task,
        )

    def update(
        self,
        task_id: str,
        *,
        name: str | _Omitted = OMITTED,
        prompt: str | _Omitted = OMITTED,
        schedule: TaskScheduleInput | None | _Omitted = OMITTED,
        enabled: bool | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Task:
        """Update the provided Task fields.

        Args:
            task_id: Task identifier.
            name: Task display name, 1 to 80 characters.
            prompt: Task prompt text. Omission retains the current value.
            schedule: One-time, interval, or cron schedule. Intervals use
                every_ms of at least 60000. Cron timezone is optional.
                None clears the schedule. Omission preserves it.
            enabled: Whether the Task is enabled.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task details.

        Raises:
            TypeError: The schedule structure or field types are invalid.
            ValueError: The Task schedule, offset datetime, cron expression, or
                timezone is invalid.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _task_body(
            agent_id=OMITTED,
            name=name,
            prompt=prompt,
            schedule=schedule,
            enabled=enabled,
            submit=OMITTED,
            user_id=OMITTED,
            metadata=metadata,
            idempotency_key=OMITTED,
        )
        if not body:
            msg = "At least one Task field must be provided."
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "PATCH",
                _task_path(task_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Task,
        )

    def delete(
        self,
        task_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Task.

        Args:
            task_id: Task identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _task_path(task_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    def submit(
        self,
        task_id: str,
        *,
        idempotency_key: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunSubmission:
        """Submit a Task Run for execution.

        The idempotency key is sent in the JSON body, not an HTTP header.

        Args:
            task_id: Task identifier.
            idempotency_key: Stable key for retrying the same operation without
                duplicating it.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Acknowledgement of the submitted Task Run.

        Raises:
            ValueError: The idempotency key is empty or not a string.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                _task_run_path(task_id),
                json_body=_task_run_body(idempotency_key),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunSubmission,
        )

    def list_runs(
        self,
        task_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunsPage:
        """Fetch one page of Task Runs.

        Args:
            task_id: Task identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _task_run_path(task_id),
                query=_cursor_limit_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunsPage,
        )

    def iter_runs(
        self,
        task_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[TaskRun]:
        """Iterate Task Runs across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            task_id: Task identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            TaskRun records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list_runs(
                task_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def get_run(
        self,
        task_id: str,
        run_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRun:
        """Fetch a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task Run details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _task_run_path(task_id, run_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRun,
        )

    def run_messages(
        self,
        task_id: str,
        run_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        after: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunMessagesPage:
        """Fetch a page of messages for a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            cursor: Continuation cursor from a previous page.
            after: Message cursor for fetching later messages.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_task_run_path(task_id, run_id)}/messages",
                query=_session_messages_query(cursor, after, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunMessagesPage,
        )

    def cancel_run(
        self,
        task_id: str,
        run_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Cancel a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_task_run_path(task_id, run_id)}/cancel",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncTasksResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Task operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def create(
        self,
        *,
        agent_id: str,
        name: str,
        prompt: str,
        schedule: TaskScheduleInput | None | _Omitted = OMITTED,
        enabled: bool | _Omitted = OMITTED,
        submit: bool | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        idempotency_key: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskCreateResponse:
        """Create a Task.

        Args:
            agent_id: Agent identifier.
            name: Task display name, 1 to 80 characters.
            prompt: Task prompt text.
            schedule: One-time, interval, or cron schedule. Intervals use
                every_ms of at least 60000. Cron timezone is optional.
                None clears the schedule. Omission leaves it unset.
            enabled: Whether the Task is enabled.
            submit: Optional initial Task Run submission.
            user_id: Caller-defined user identifier.
            metadata: Caller-defined JSON metadata.
            idempotency_key: Stable key for retrying the same create without
                creating another Task.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Created Task and any submitted initial Run.

        Raises:
            TypeError: The schedule structure or field types are invalid.
            ValueError: The Task schedule, offset datetime, cron expression, or
                timezone is invalid.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                _task_path(),
                json_body=_task_body(
                    agent_id=agent_id,
                    name=name,
                    prompt=prompt,
                    schedule=schedule,
                    enabled=enabled,
                    submit=submit,
                    user_id=user_id,
                    metadata=metadata,
                    idempotency_key=idempotency_key,
                ),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskCreateResponse,
        )

    async def list(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TasksPage:
        """Fetch one page of Task records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _task_path(),
                query=_tasks_query(agent_id, user_id, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TasksPage,
        )

    async def iter(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[TaskListItem]:
        """Iterate Task records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            TaskListItem records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                agent_id=agent_id,
                user_id=user_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for task in page.data:
                yield task
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def get(
        self,
        task_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Task:
        """Fetch the requested Task.

        Args:
            task_id: Task identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _task_path(task_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Task,
        )

    async def update(
        self,
        task_id: str,
        *,
        name: str | _Omitted = OMITTED,
        prompt: str | _Omitted = OMITTED,
        schedule: TaskScheduleInput | None | _Omitted = OMITTED,
        enabled: bool | _Omitted = OMITTED,
        metadata: dict[str, object] | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Task:
        """Update the provided Task fields.

        Args:
            task_id: Task identifier.
            name: Task display name, 1 to 80 characters.
            prompt: Task prompt text. Omission retains the current value.
            schedule: One-time, interval, or cron schedule. Intervals use
                every_ms of at least 60000. Cron timezone is optional.
                None clears the schedule. Omission preserves it.
            enabled: Whether the Task is enabled.
            metadata: Caller-defined JSON metadata.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task details.

        Raises:
            TypeError: The schedule structure or field types are invalid.
            ValueError: The Task schedule, offset datetime, cron expression, or
                timezone is invalid.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        body = _task_body(
            agent_id=OMITTED,
            name=name,
            prompt=prompt,
            schedule=schedule,
            enabled=enabled,
            submit=OMITTED,
            user_id=OMITTED,
            metadata=metadata,
            idempotency_key=OMITTED,
        )
        if not body:
            msg = "At least one Task field must be provided."
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "PATCH",
                _task_path(task_id),
                json_body=body,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Task,
        )

    async def delete(
        self,
        task_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Task.

        Args:
            task_id: Task identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _task_path(task_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    async def submit(
        self,
        task_id: str,
        *,
        idempotency_key: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunSubmission:
        """Submit a Task Run for execution.

        The idempotency key is sent in the JSON body, not an HTTP header.

        Args:
            task_id: Task identifier.
            idempotency_key: Stable key for retrying the same operation without
                duplicating it.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Acknowledgement of the submitted Task Run.

        Raises:
            ValueError: The idempotency key is empty or not a string.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                _task_run_path(task_id),
                json_body=_task_run_body(idempotency_key),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunSubmission,
        )

    async def list_runs(
        self,
        task_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunsPage:
        """Fetch one page of Task Runs.

        Args:
            task_id: Task identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _task_run_path(task_id),
                query=_cursor_limit_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunsPage,
        )

    async def iter_runs(
        self,
        task_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[TaskRun]:
        """Iterate Task Runs across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            task_id: Task identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            TaskRun records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list_runs(
                task_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for run in page.data:
                yield run
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def get_run(
        self,
        task_id: str,
        run_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRun:
        """Fetch a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Task Run details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _task_run_path(task_id, run_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRun,
        )

    async def run_messages(
        self,
        task_id: str,
        run_id: str,
        *,
        cursor: str | _Omitted = OMITTED,
        after: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> TaskRunMessagesPage:
        """Fetch a page of messages for a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            cursor: Continuation cursor from a previous page.
            after: Message cursor for fetching later messages.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_task_run_path(task_id, run_id)}/messages",
                query=_session_messages_query(cursor, after, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            TaskRunMessagesPage,
        )

    async def cancel_run(
        self,
        task_id: str,
        run_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Cancel a Task Run.

        Args:
            task_id: Task identifier.
            run_id: Task Run identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_task_run_path(task_id, run_id)}/cancel",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class SessionsResource:
    def __init__(self, transport: SyncTransport) -> None:
        """Bind Session operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    def fork(
        self,
        agent_id: str,
        session_id: str,
        *,
        message_id: str,
        idempotency_key: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionResponse:
        """Fork a Session at the selected message.

        The idempotency_key replaces any Idempotency-Key in extra_headers.

        Retry uncertain acknowledgements with the same explicit key.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            message_id: Message at which to fork the Session.
            idempotency_key: Stable key for retrying the same operation without
                duplicating it.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Session response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        headers = {
            name: value
            for name, value in (extra_headers or {}).items()
            if name.lower() != "idempotency-key"
        }
        headers["Idempotency-Key"] = idempotency_key
        return self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/fork",
                json_body={"messageId": message_id},
                extra_headers=headers,
                timeout=timeout,
            ),
            SessionResponse,
        )

    def get(
        self,
        agent_id: str,
        session_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionResponse:
        """Fetch the requested Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Session response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _sessions_path(agent_id, session_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionResponse,
        )

    def list(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionsPage:
        """Fetch one page of Session records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _sessions_path(agent_id),
                query=_sessions_query(user_id, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionsPage,
        )

    def list_latest(
        self,
        *,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        by_agent: bool | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> LatestSessionsPage:
        """Fetch the latest Session for each matching user or Agent grouping.

        Args:
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            by_agent: Whether latest Sessions are grouped by Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                "/v1/sessions/latest",
                query=_sessions_query(user_id, cursor, limit, by_agent),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            LatestSessionsPage,
        )

    def iter(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[Session]:
        """Iterate Session records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Session records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                agent_id=agent_id,
                user_id=user_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def messages(
        self,
        *,
        agent_id: str,
        session_id: str,
        cursor: str | _Omitted = OMITTED,
        after: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionMessagesPage:
        """Fetch a page of Session messages.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            after: Message cursor for fetching later messages.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/messages",
                query=_session_messages_query(cursor, after, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionMessagesPage,
        )

    def tool_approvals(
        self,
        *,
        agent_id: str,
        session_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ToolApprovals:
        """Fetch pending tool approvals for the Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Pending approval round for the Session.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/tool-approvals",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ToolApprovals,
        )

    def submit_input(
        self,
        *,
        agent_id: str,
        session_id: str,
        request_id: str,
        message: Mapping[str, object],
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionInputResponse:
        """Steer a running Turn with one user message.

        Retry with the same request_id and message to recover its receipt.
        If steering is unavailable, no message waits for a future Turn.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            request_id: Idempotency identifier for the submitted input.
            message: Message to queue for the Session.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Acknowledgement of the queued input.

        Raises:
            ValueError: request_id is empty or a dot segment.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/inputs",
                json_body=_inputs_body(request_id, message),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionInputResponse,
        )

    def inputs(
        self,
        *,
        agent_id: str,
        session_id: str,
        include_completed: bool | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionInputsPage:
        """List input receipts in admission order with Session activity.

        Poll without cursor to observe changes. cursor only pages the results.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            include_completed: Whether to include completed inputs.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/inputs",
                query=_inputs_query(include_completed, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionInputsPage,
        )

    def stop(
        self,
        *,
        agent_id: str,
        session_id: str,
        turn_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionStopResponse:
        """Record cancellation and return immediately.

        Read the existing Turn stream to observe settlement.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            turn_id: Active Turn identifier to stop.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Result of the stop request.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/stop",
                json_body={"turnId": turn_id},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionStopResponse,
        )

    def delete(
        self,
        *,
        agent_id: str,
        session_id: str,
        delete_artifacts: bool,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            delete_artifacts: Whether to delete Artifacts associated with the
                Session.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _sessions_path(agent_id, session_id),
                query={"deleteArtifacts": str(delete_artifacts).lower()},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncSessionsResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Session operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def fork(
        self,
        agent_id: str,
        session_id: str,
        *,
        message_id: str,
        idempotency_key: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionResponse:
        """Fork a Session at the selected message.

        The idempotency_key replaces any Idempotency-Key in extra_headers.

        Retry uncertain acknowledgements with the same explicit key.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            message_id: Message at which to fork the Session.
            idempotency_key: Stable key for retrying the same operation without
                duplicating it.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Session response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        headers = {
            name: value
            for name, value in (extra_headers or {}).items()
            if name.lower() != "idempotency-key"
        }
        headers["Idempotency-Key"] = idempotency_key
        return await self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/fork",
                json_body={"messageId": message_id},
                extra_headers=headers,
                timeout=timeout,
            ),
            SessionResponse,
        )

    async def get(
        self,
        agent_id: str,
        session_id: str,
        *,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionResponse:
        """Fetch the requested Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Session response details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _sessions_path(agent_id, session_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionResponse,
        )

    async def list(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionsPage:
        """Fetch one page of Session records.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _sessions_path(agent_id),
                query=_sessions_query(user_id, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionsPage,
        )

    async def list_latest(
        self,
        *,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        by_agent: bool | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> LatestSessionsPage:
        """Fetch the latest Session for each matching user or Agent grouping.

        Args:
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            by_agent: Whether latest Sessions are grouped by Agent.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/sessions/latest",
                query=_sessions_query(user_id, cursor, limit, by_agent),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            LatestSessionsPage,
        )

    async def iter(
        self,
        *,
        agent_id: str,
        user_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[Session]:
        """Iterate Session records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            agent_id: Agent identifier.
            user_id: Caller-defined user identifier.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Session records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                agent_id=agent_id,
                user_id=user_id,
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for session in page.data:
                yield session
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def messages(
        self,
        *,
        agent_id: str,
        session_id: str,
        cursor: str | _Omitted = OMITTED,
        after: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionMessagesPage:
        """Fetch a page of Session messages.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            after: Message cursor for fetching later messages.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/messages",
                query=_session_messages_query(cursor, after, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionMessagesPage,
        )

    async def tool_approvals(
        self,
        *,
        agent_id: str,
        session_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ToolApprovals:
        """Fetch pending tool approvals for the Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Pending approval round for the Session.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/tool-approvals",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ToolApprovals,
        )

    async def submit_input(
        self,
        *,
        agent_id: str,
        session_id: str,
        request_id: str,
        message: Mapping[str, object],
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionInputResponse:
        """Steer a running Turn with one user message.

        Retry with the same request_id and message to recover its receipt.
        If steering is unavailable, no message waits for a future Turn.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            request_id: Idempotency identifier for the submitted input.
            message: Message to queue for the Session.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Acknowledgement of the queued input.

        Raises:
            ValueError: request_id is empty or a dot segment.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/inputs",
                json_body=_inputs_body(request_id, message),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionInputResponse,
        )

    async def inputs(
        self,
        *,
        agent_id: str,
        session_id: str,
        include_completed: bool | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionInputsPage:
        """List input receipts in admission order with Session activity.

        Poll without cursor to observe changes. cursor only pages the results.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            include_completed: Whether to include completed inputs.
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_sessions_path(agent_id, session_id)}/inputs",
                query=_inputs_query(include_completed, cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionInputsPage,
        )

    async def stop(
        self,
        *,
        agent_id: str,
        session_id: str,
        turn_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SessionStopResponse:
        """Record cancellation and return immediately.

        Read the existing Turn stream to observe settlement.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            turn_id: Active Turn identifier to stop.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Result of the stop request.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_sessions_path(agent_id, session_id)}/stop",
                json_body={"turnId": turn_id},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SessionStopResponse,
        )

    async def delete(
        self,
        *,
        agent_id: str,
        session_id: str,
        delete_artifacts: bool,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Session.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            delete_artifacts: Whether to delete Artifacts associated with the
                Session.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _sessions_path(agent_id, session_id),
                query={"deleteArtifacts": str(delete_artifacts).lower()},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AsyncArtifactsResource:
    def __init__(self, transport: AsyncTransport) -> None:
        """Bind Artifact operations to the transport.

        Args:
            transport: Transport used for requests.
        """
        self._transport = transport

    async def list(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ArtifactsPage:
        """Fetch one page of Artifact records.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                "/v1/artifacts",
                query=_artifacts_query(agent_id, session_id, cursor),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ArtifactsPage,
        )

    async def iter(
        self,
        *,
        agent_id: str | _Omitted = OMITTED,
        session_id: str | _Omitted = OMITTED,
        cursor: str | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[Artifact]:
        """Iterate Artifact records across all pages.

        Pages are fetched lazily until the API returns no continuation cursor.

        Args:
            agent_id: Agent identifier.
            session_id: Session identifier.
            cursor: Continuation cursor from a previous page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Artifact records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                agent_id=agent_id,
                session_id=session_id,
                cursor=next_cursor,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for artifact in page.data:
                yield artifact
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def create_download_url(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> ArtifactDownloadUrl:
        """Create an expiring Artifact download URL.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Expiring URL for downloading the Artifact.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "POST",
                f"{_artifact_path(artifact_id)}/download-url",
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            ArtifactDownloadUrl,
        )

    async def get(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Artifact:
        """Fetch the requested Artifact.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Requested Artifact details.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _artifact_path(artifact_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            Artifact,
        )

    async def delete(
        self,
        *,
        artifact_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Artifact.

        Args:
            artifact_id: Artifact identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _artifact_path(artifact_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )


class AgentSkillsResource:
    def __init__(self, transport: SyncTransport, agent_id: str) -> None:
        """Bind Skill operations to the transport.

        Args:
            transport: Transport used for requests.
            agent_id: Agent identifier.
        """
        self._transport = transport
        self._agent_id = agent_id

    def create(
        self,
        *,
        path: Literal["SKILL.md"],
        content: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Create a Skill.

        Args:
            path: Path to the requested file.
            content: UTF-8 Skill document or file contents.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        if path != "SKILL.md":
            msg = "path must be SKILL.md"
            raise ValueError(msg)
        return self._transport.request(
            _Request(
                "POST",
                _skill_path(self._agent_id),
                json_body={"path": path, "content": content},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    def upload(
        self,
        *,
        archive_type: SkillArchiveType,
        file: UploadFile,
        filename: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Upload a Skill archive.

        Paths are opened and closed by the SDK. Caller-owned file objects remain
        open.

        Args:
            archive_type: Archive format: zip, tar, or tar.gz.
            file: File upload input.
            filename: Filename supplied for the upload.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            ValueError: The archive format is unsupported.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        with _skill_upload_request(
            agent_id=self._agent_id,
            archive_type=archive_type,
            file=file,
            filename=filename,
            extra_headers=extra_headers,
            timeout=timeout,
        ) as request:
            return self._transport.request(request, SkillDetail)

    def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillsPage:
        """Fetch one page of Skill records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _skill_path(self._agent_id),
                query=_skills_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillsPage,
        )

    def iter(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> Iterator[Skill]:
        """Iterate Skill records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Skill records in server order.
        """
        next_cursor = cursor
        while True:
            page = self.list(
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            yield from page.data
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    def get(
        self,
        *,
        skill_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Fetch the requested Skill.

        Args:
            skill_id: Skill identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                _skill_path(self._agent_id, skill_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    def delete(
        self,
        *,
        skill_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Skill.

        Args:
            skill_id: Skill identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                _skill_path(self._agent_id, skill_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    def read_file(
        self,
        *,
        skill_id: str,
        path: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> bytes:
        """Read a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Downloaded response bytes.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "GET",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            RESPONSE_BYTES,
        )

    def replace_file(
        self,
        *,
        skill_id: str,
        path: str,
        content: bytes,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Replace a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            content: Raw file bytes.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "PUT",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                content=content,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    def delete_file(
        self,
        *,
        skill_id: str,
        path: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Delete a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return self._transport.request(
            _Request(
                "DELETE",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    def copy(
        self,
        *,
        skill_id: str,
        destination_agent_ids: Sequence[str],
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> _SkillCopyResultList:
        """Copy Skills to another Agent.

        Args:
            skill_id: Skill identifier.
            destination_agent_ids: Agents that receive a copy of the Skill.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Per-destination copy results.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        response = self._transport.request(
            _Request(
                "POST",
                f"{_skill_path(self._agent_id, skill_id)}/copies",
                json_body={"agentIds": list(destination_agent_ids)},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillCopyResults,
        )
        return response.root


class AsyncAgentSkillsResource:
    def __init__(self, transport: AsyncTransport, agent_id: str) -> None:
        """Bind Skill operations to the transport.

        Args:
            transport: Transport used for requests.
            agent_id: Agent identifier.
        """
        self._transport = transport
        self._agent_id = agent_id

    async def create(
        self,
        *,
        path: Literal["SKILL.md"],
        content: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Create a Skill.

        Args:
            path: Path to the requested file.
            content: UTF-8 Skill document or file contents.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        if path != "SKILL.md":
            msg = "path must be SKILL.md"
            raise ValueError(msg)
        return await self._transport.request(
            _Request(
                "POST",
                _skill_path(self._agent_id),
                json_body={"path": path, "content": content},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    async def upload(
        self,
        *,
        archive_type: SkillArchiveType,
        file: UploadFile,
        filename: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Upload a Skill archive.

        Paths are opened and closed by the SDK. Caller-owned file objects remain
        open.

        Args:
            archive_type: Archive format: zip, tar, or tar.gz.
            file: File upload input.
            filename: Filename supplied for the upload.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            ValueError: The archive format is unsupported.
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        with _skill_upload_request(
            agent_id=self._agent_id,
            archive_type=archive_type,
            file=file,
            filename=filename,
            extra_headers=extra_headers,
            timeout=timeout,
        ) as request:
            return await self._transport.request(request, SkillDetail)

    async def list(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillsPage:
        """Fetch one page of Skill records.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            One page of matching records and its continuation cursor.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _skill_path(self._agent_id),
                query=_skills_query(cursor, limit),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillsPage,
        )

    async def iter(
        self,
        *,
        cursor: str | _Omitted = OMITTED,
        limit: int | _Omitted = OMITTED,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> AsyncIterator[Skill]:
        """Iterate Skill records across all pages.

        Pages are fetched lazily. limit controls each page, not the total.

        Args:
            cursor: Continuation cursor from a previous page.
            limit: Maximum number of items per page.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Yields:
            Skill records in server order.
        """
        next_cursor = cursor
        while True:
            page = await self.list(
                cursor=next_cursor,
                limit=limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )
            for skill in page.data:
                yield skill
            if page.next_cursor is None:
                return
            next_cursor = page.next_cursor

    async def get(
        self,
        *,
        skill_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Fetch the requested Skill.

        Args:
            skill_id: Skill identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                _skill_path(self._agent_id, skill_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    async def delete(
        self,
        *,
        skill_id: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> None:
        """Delete the requested Skill.

        Args:
            skill_id: Skill identifier.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                _skill_path(self._agent_id, skill_id),
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            None,
        )

    async def read_file(
        self,
        *,
        skill_id: str,
        path: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> bytes:
        """Read a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Downloaded response bytes.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "GET",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            RESPONSE_BYTES,
        )

    async def replace_file(
        self,
        *,
        skill_id: str,
        path: str,
        content: bytes,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Replace a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            content: Raw file bytes.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "PUT",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                content=content,
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    async def delete_file(
        self,
        *,
        skill_id: str,
        path: str,
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> SkillDetail:
        """Delete a file within an attached Skill.

        Args:
            skill_id: Skill identifier.
            path: Path to the requested file.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Skill details and file listing.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        return await self._transport.request(
            _Request(
                "DELETE",
                f"{_skill_path(self._agent_id, skill_id)}/files",
                query={"path": path},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillDetail,
        )

    async def copy(
        self,
        *,
        skill_id: str,
        destination_agent_ids: Sequence[str],
        extra_headers: Mapping[str, str] | None = None,
        timeout: Timeout | _Omitted = OMITTED,
    ) -> _SkillCopyResultList:
        """Copy Skills to another Agent.

        Args:
            skill_id: Skill identifier.
            destination_agent_ids: Agents that receive a copy of the Skill.
            extra_headers: Headers for this request. Authorization uses the client
                API key.
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Per-destination copy results.

        Raises:
            APIStatusError: The API returns a non-success status.
            APIConnectionError: The HTTP request fails before a complete response.
            APITimeoutError: The HTTP request times out.
        """
        response = await self._transport.request(
            _Request(
                "POST",
                f"{_skill_path(self._agent_id, skill_id)}/copies",
                json_body={"agentIds": list(destination_agent_ids)},
                extra_headers=extra_headers,
                timeout=timeout,
            ),
            SkillCopyResults,
        )
        return response.root
