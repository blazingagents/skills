from __future__ import annotations

import json
import logging
from collections.abc import Callable, Mapping
from contextlib import suppress
from copy import copy
from dataclasses import dataclass
from time import perf_counter
from typing import Any, Protocol, TypeVar, cast, overload
from urllib.parse import quote

import httpx
from pydantic import BaseModel
from pydantic.alias_generators import to_camel

from ._downloads import AsyncByteStream
from ._errors import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    CredentialEchoError,
    StreamError,
)
from ._models import ResponseMeta
from ._responses import Completion
from ._types import Timeout

_LOGGER = logging.getLogger("blazing_agents")
_ModelT = TypeVar("_ModelT", bound=BaseModel)
_StreamT = TypeVar("_StreamT")
_T = TypeVar("_T")
_MIN_SUBSTRING_SECRET_LENGTH = 8
_CREDENTIAL_KEYS = frozenset(
    {
        "apiKey",
        "api_key",
        "botToken",
        "bot_token",
        "signingSecret",
        "signing_secret",
        "webhookSecret",
        "webhook_secret",
        "bearerToken",
        "bearer_token",
        "clientSecret",
        "client_secret",
        "credential",
    }
)


class _ResponseMetaModel(Protocol):
    def _attach_response_meta(self, meta: ResponseMeta) -> None: ...


class _Omitted:
    pass


OMITTED = _Omitted()


def wire_fields(**fields: _T | _Omitted) -> dict[str, _T]:
    """Rename snake_case fields to camelCase wire names, leaving out OMITTED ones.

    A trailing underscore, as in ``from_``, is dropped from the wire name.
    """
    return {
        to_camel(name.rstrip("_")): value
        for name, value in fields.items()
        if not isinstance(value, _Omitted)
    }


@dataclass(frozen=True)
class ResponseObservation:
    method: str
    path: str
    status: int
    duration_ms: float
    request_id: str | None
    client_request_id: str | None


def path_segment(name: str, value: str) -> str:
    """Percent-encode one URL path segment.

    Args:
        name: Parameter name used in the error message.
        value: Identifier to place in the path.

    Returns:
        The percent-encoded segment.

    Raises:
        ValueError: The identifier is empty, ``.`` or ``..``, which would change
            the request path.
    """
    if value in {"", ".", ".."}:
        raise ValueError(f"{name} must not be empty, '.' or '..'.")
    return quote(value, safe="")


@dataclass(frozen=True)
class _Request:
    method: str
    path: str
    client_request_id: str | None = None
    query: Mapping[str, str | int] | None = None
    json_body: object = OMITTED
    files: object = OMITTED
    content: object = OMITTED
    extra_headers: Mapping[str, str] | None = None
    timeout: Timeout | _Omitted = OMITTED
    sensitive_values: tuple[str, ...] = ()
    credential_bearing: bool = False
    """The contract marks the operation ``x-credential-bearing``."""
    streamed_read: bool = False
    """Read the body through a streamed response, as object generation needs."""


class _TransportConfig:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        default_headers: Mapping[str, str] | None,
        timeout: Timeout,
        user_agent: str,
        on_response: Callable[[ResponseObservation], None] | None,
        client_request_id: str | None,
    ) -> None:
        """Hold the authentication, header, and timeout settings for requests.

        Args:
            api_key: Resolved API key used for authentication.
            base_url: API base URL. Trailing slashes are removed.
            default_headers: Headers applied to every request.
            timeout: Default HTTP timeout in seconds, an HTTPX timeout, or None.
            user_agent: User-Agent header value.
            on_response: Response observer. Callback exceptions are ignored.
            client_request_id: Caller correlation ID sent as X-Client-Request-Id.
        """
        normalized_url = base_url.rstrip("/")
        if not normalized_url:
            msg = "base_url must not be empty"
            raise ValueError(msg)
        self.api_key = api_key
        self.base_url = normalized_url
        self.default_headers = httpx.Headers(default_headers)
        self.timeout = timeout
        self.user_agent = user_agent
        self.on_response = on_response
        self.client_request_id = client_request_id
        self.scope_user_id: str | None = None

    def with_client_request_id(self, client_request_id: str) -> _TransportConfig:
        """Copy configuration with a caller correlation ID.

        Args:
            client_request_id: Caller correlation ID sent as X-Client-Request-Id.

        Returns:
            Configuration copy with the requested correlation ID.
        """
        config = copy(self)
        config.client_request_id = client_request_id
        return config

    def with_scope_user_id(self, user_id: str) -> _TransportConfig:
        """Copy configuration with an end-user scope.

        Args:
            user_id: End-user ID sent as X-BA-User-Id.

        Returns:
            Configuration copy whose requests act for the end user.
        """
        config = copy(self)
        config.scope_user_id = user_id
        return config

    def resolved_client_request_id(self, request: _Request) -> str | None:
        """Resolve the request ID override before the client default.

        Args:
            request: Prepared HTTP request.

        Returns:
            Request correlation ID, client default, or None.
        """
        return (
            request.client_request_id
            if request.client_request_id is not None
            else self.client_request_id
        )

    def url(self, path: str) -> str:
        """Append an endpoint path to the normalized API base URL.

        Args:
            path: Endpoint path to append to the base URL.

        Returns:
            Base URL concatenated with the endpoint path.
        """
        return f"{self.base_url}{path}"

    def headers(self, request: _Request) -> httpx.Headers:
        """Build headers with API authentication and caller correlation.

        Args:
            request: Prepared HTTP request.

        Returns:
            Merged request headers.
        """
        headers = httpx.Headers({"user-agent": self.user_agent})
        headers.update(self.default_headers)
        if request.extra_headers is not None:
            headers.update(request.extra_headers)
        headers.pop("x-request-id", None)
        headers["authorization"] = f"Bearer {self.api_key}"
        resolved = self.resolved_client_request_id(request)
        if resolved is not None:
            headers["x-client-request-id"] = resolved
        if self.scope_user_id is not None:
            headers["x-ba-user-id"] = self.scope_user_id
        return headers

    def observe(
        self,
        request: _Request,
        *,
        started_at: float,
        response: httpx.Response,
    ) -> None:
        """Call the response observer and ignore its exceptions.

        Args:
            request: Prepared HTTP request.
            started_at: Request start time from perf_counter.
            response: HTTPX response supplying the body and response metadata.
        """
        if self.on_response is None:
            return
        with suppress(Exception):
            self.on_response(
                ResponseObservation(
                    method=request.method,
                    path=request.path,
                    status=response.status_code,
                    duration_ms=(perf_counter() - started_at) * 1_000,
                    request_id=response.headers.get("x-request-id"),
                    client_request_id=response.request.headers.get(
                        "x-client-request-id"
                    ),
                )
            )

    def request_timeout(self, timeout: Timeout | _Omitted) -> Timeout:
        """Resolve an omitted timeout to the client default.

        Args:
            timeout: Request timeout override. OMITTED inherits the client timeout.

        Returns:
            Request timeout override or the client default.
        """
        return self.timeout if isinstance(timeout, _Omitted) else timeout

    def log(
        self,
        request: _Request,
        *,
        started_at: float,
        response: httpx.Response | None,
    ) -> None:
        """Log request status and duration without request contents.

        Args:
            request: Prepared HTTP request.
            started_at: Request start time from perf_counter.
            response: HTTPX response supplying the body and response metadata.
        """
        request_id = (
            response.headers.get("x-request-id") if response is not None else None
        )
        _LOGGER.debug(
            "HTTP request method=%s path=%s status=%s elapsed_ms=%.3f request_id=%s",
            request.method,
            request.path,
            response.status_code if response is not None else None,
            (perf_counter() - started_at) * 1_000,
            request_id,
        )


def _status_error(
    response: httpx.Response,
    sensitive_values: tuple[str, ...],
) -> APIStatusError:
    """Build an API status error with credential values redacted."""
    raw_body = response.text
    code = "invalid_response"
    message = "The server returned an invalid error response."
    details: Mapping[str, Any] | None = None
    param: str | None = None
    try:
        parsed: object = json.loads(raw_body)
    except json.JSONDecodeError:
        parsed = None
        body = "[REDACTED]" if sensitive_values else raw_body
    else:
        parsed = _redact_sensitive_values(parsed, sensitive_values)
        body = json.dumps(parsed, separators=(",", ":"))
    if isinstance(parsed, dict):
        parsed_mapping = cast(dict[str, object], parsed)
        error = parsed_mapping.get("error")
        if isinstance(error, dict):
            error_mapping = cast(dict[str, object], error)
            parsed_code = error_mapping.get("code")
            parsed_message = error_mapping.get("message")
            parsed_details = error_mapping.get("details")
            parsed_param = error_mapping.get("param")
            if isinstance(parsed_code, str) and isinstance(parsed_message, str):
                code = parsed_code
                message = parsed_message
                if isinstance(parsed_details, dict):
                    details = cast(dict[str, Any], parsed_details)
                if isinstance(parsed_param, str):
                    param = parsed_param
    headers = _redact_headers(response.headers, sensitive_values)
    return APIStatusError(
        message,
        status_code=response.status_code,
        headers=headers,
        code=code,
        details=details,
        param=param,
        request_id=headers.get("x-request-id"),
        response_body=body,
    )


def _redact_headers(
    headers: httpx.Headers,
    sensitive_values: tuple[str, ...],
) -> httpx.Headers:
    """Redact credential values in response headers."""
    if not sensitive_values:
        return headers
    return httpx.Headers(
        [
            (name, _redact_string(value, sensitive_values))
            for name, value in headers.multi_items()
        ]
    )


def _redact_string(value: str, sensitive_values: tuple[str, ...]) -> str:
    """Redact exact short secrets and occurrences of longer secrets."""
    for secret in sensitive_values:
        if len(secret) >= _MIN_SUBSTRING_SECRET_LENGTH:
            value = value.replace(secret, "[REDACTED]")
        elif value == secret:
            return "[REDACTED]"
    return value


def _redact_sensitive_values(
    value: object,
    sensitive_values: tuple[str, ...],
) -> object:
    """Recursively redact credential values in JSON data."""
    if isinstance(value, dict):
        fields = cast(dict[str, object], value)
        return {
            key: _redact_sensitive_values(item, sensitive_values)
            for key, item in fields.items()
        }
    if isinstance(value, list):
        items = cast(list[object], value)
        return [_redact_sensitive_values(item, sensitive_values) for item in items]
    if isinstance(value, str):
        return _redact_string(value, sensitive_values)
    return value


def _model(
    response: httpx.Response,
    model: type[_ModelT],
    sensitive_values: tuple[str, ...],
) -> _ModelT:
    """Validate a response model and attach the response metadata."""
    value = model.model_validate_json(response.content)
    cast(_ResponseMetaModel, value)._attach_response_meta(
        ResponseMeta._from_response(
            response, _redact_headers(response.headers, sensitive_values)
        )
    )
    return value


def _reject_credential_echo(
    response: httpx.Response,
    sensitive_values: tuple[str, ...],
) -> None:
    """Raise when a credential operation's response carries credential material.

    A body that is not JSON passes, so the decoder reports it.
    """
    try:
        decoded: object = json.loads(response.content)
    except json.JSONDecodeError:
        return
    if _contains_credential_material(decoded, sensitive_values):
        raise CredentialEchoError(request_id=response.headers.get("x-request-id"))


def _contains_credential_material(
    value: object,
    sensitive_values: tuple[str, ...],
) -> bool:
    """Check JSON data for a credential key or a submitted secret."""
    if isinstance(value, dict):
        fields = cast(dict[str, object], value)
        return any(
            key in _CREDENTIAL_KEYS
            or _contains_credential_material(item, sensitive_values)
            for key, item in fields.items()
        )
    if isinstance(value, list):
        items = cast(list[object], value)
        return any(
            _contains_credential_material(item, sensitive_values) for item in items
        )
    if isinstance(value, str):
        return any(
            value == secret
            or (len(secret) >= _MIN_SUBSTRING_SECRET_LENGTH and secret in value)
            for secret in sensitive_values
        )
    return False


def _request_options(
    config: _TransportConfig,
    request: _Request,
) -> dict[str, Any]:
    """Build HTTPX options for a nonstreaming request."""
    options: dict[str, Any] = {
        "params": request.query,
        "headers": config.headers(request),
        "timeout": config.request_timeout(request.timeout),
    }
    if request.json_body is not OMITTED:
        options["json"] = request.json_body
    if request.files is not OMITTED:
        options["files"] = request.files
    if request.content is not OMITTED:
        options["content"] = request.content
    return options


def _stream_request_options(
    config: _TransportConfig,
    request: _Request,
) -> dict[str, Any]:
    """Build HTTPX options for a streaming request."""
    options = _request_options(config, request)
    configured = config.request_timeout(request.timeout)
    if configured is None:
        options["timeout"] = None
    else:
        timeout = (
            configured
            if isinstance(configured, httpx.Timeout)
            else httpx.Timeout(configured)
        )
        options["timeout"] = httpx.Timeout(
            connect=timeout.connect,
            read=None,
            write=timeout.write,
            pool=timeout.pool,
        )
    return options


_Decoder = Callable[[httpx.Response, tuple[str, ...]], _T]
"""Turn a successful response into a value, given the request's sensitive values."""


def decode_model(model: type[_ModelT]) -> _Decoder[_ModelT]:
    """Decode the response body into a Pydantic model."""
    return lambda response, sensitive_values: _model(response, model, sensitive_values)


def decode_none(_response: httpx.Response, _sensitive: tuple[str, ...]) -> None:
    """Discard the response body."""


def decode_bytes(response: httpx.Response, _sensitive: tuple[str, ...]) -> bytes:
    """Return the downloaded response bytes."""
    return response.content


def decode_completion(
    response: httpx.Response, _sensitive: tuple[str, ...]
) -> Completion:
    """Return generated text with its server request_id."""
    return Completion(response.text, response)


def _decoded(response: httpx.Response, request: _Request, decode: _Decoder[_T]) -> _T:
    """Raise for a failed or credential-echoing response, else decode it."""
    if not response.is_success:
        raise _status_error(response, request.sensitive_values)
    if request.credential_bearing:
        _reject_credential_echo(response, request.sensitive_values)
    return decode(response, request.sensitive_values)


class AsyncTransport:
    def __init__(
        self,
        config: _TransportConfig,
        http_client: httpx.AsyncClient | None,
    ) -> None:
        """Send requests through a new or caller-supplied HTTPX client.

        Args:
            config: Authentication, headers, and timeout configuration.
            http_client: HTTPX client to reuse. The SDK closes only clients it
                creates.
        """
        self._config = config
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient()

    def with_client_request_id(self, client_request_id: str) -> AsyncTransport:
        """Copy configuration with a caller correlation ID.

        Args:
            client_request_id: Caller correlation ID sent as X-Client-Request-Id.

        Returns:
            Transport view sharing the HTTP client.
        """
        return AsyncTransport(
            self._config.with_client_request_id(client_request_id),
            self._client,
        )

    def with_scope_user_id(self, user_id: str) -> AsyncTransport:
        """Copy configuration with an end-user scope.

        Args:
            user_id: End-user ID sent as X-BA-User-Id.

        Returns:
            Transport view sharing the HTTP client.
        """
        return AsyncTransport(self._config.with_scope_user_id(user_id), self._client)

    async def request(self, request: _Request, decode: _Decoder[_T]) -> _T:
        """Send an HTTP request and decode its response.

        Args:
            request: Prepared HTTP request.
            decode: Decoder for a successful response.

        Returns:
            The decoded response.

        Raises:
            StreamError: Response body read failed.
        """
        started_at = perf_counter()
        response: httpx.Response | None = None
        transport_error: APIConnectionError | None = None
        try:
            if request.streamed_read:
                built = self._client.build_request(
                    request.method,
                    self._config.url(request.path),
                    **_request_options(self._config, request),
                )
                response = await self._client.send(built, stream=True)
                self._config.observe(request, started_at=started_at, response=response)
                try:
                    await response.aread()
                except httpx.HTTPError as error:
                    raise StreamError(
                        "Response body read failed.",
                        response=response,
                    ) from error
            else:
                response = await self._client.request(
                    request.method,
                    self._config.url(request.path),
                    **_request_options(self._config, request),
                )
                self._config.observe(request, started_at=started_at, response=response)
        except httpx.TimeoutException:
            transport_error = APITimeoutError("Request timed out.")
        except httpx.RequestError:
            transport_error = APIConnectionError("Connection failed.")
        finally:
            if request.streamed_read and response is not None:
                await response.aclose()
            self._config.log(request, started_at=started_at, response=response)
        if transport_error is not None:
            raise transport_error from None
        assert response is not None
        return _decoded(response, request, decode)

    @overload
    async def stream(self, request: _Request) -> AsyncByteStream:
        """Send an HTTP request and wrap its streamed response.

        Args:
            request: Prepared HTTP request.

        Returns:
            Open byte stream.
        """
        ...

    @overload
    async def stream(
        self,
        request: _Request,
        response_factory: Callable[[httpx.Response], _StreamT],
    ) -> _StreamT:
        """Send an HTTP request and wrap its streamed response.

        Args:
            request: Prepared HTTP request.
            response_factory: Factory that wraps the open streaming response.

        Returns:
            Stream returned by response_factory.
        """
        ...

    async def stream(
        self,
        request: _Request,
        response_factory: Callable[[httpx.Response], _StreamT] | None = None,
    ) -> AsyncByteStream | _StreamT:
        """Send an HTTP request and wrap its streamed response.

        Args:
            request: Prepared HTTP request.
            response_factory: Factory that wraps the open streaming response.

        Returns:
            Open byte stream, or the stream returned by response_factory.

        Raises:
            AssertionError: stream response did not produce a stream
        """
        started_at = perf_counter()
        response: httpx.Response | None = None
        transport_error: APIConnectionError | None = None
        stream_error: StreamError | None = None
        try:
            built = self._client.build_request(
                request.method,
                self._config.url(request.path),
                **_stream_request_options(self._config, request),
            )
            response = await self._client.send(built, stream=True)
            self._config.observe(request, started_at=started_at, response=response)
            if not response.is_success:
                read_failed = False
                try:
                    await response.aread()
                except httpx.HTTPError:
                    read_failed = True
                finally:
                    await response.aclose()
                if read_failed:
                    stream_error = StreamError(
                        "Stream read failed.",
                        response=response,
                    )
                else:
                    raise _status_error(response, request.sensitive_values)
            if stream_error is None:
                factory = (
                    AsyncByteStream if response_factory is None else response_factory
                )
                try:
                    return factory(response)
                except BaseException:
                    await response.aclose()
                    raise
        except httpx.TimeoutException:
            transport_error = APITimeoutError("Request timed out.")
        except httpx.RequestError:
            transport_error = APIConnectionError("Connection failed.")
        finally:
            self._config.log(request, started_at=started_at, response=response)
        if stream_error is not None:
            raise stream_error from None
        if transport_error is not None:
            raise transport_error from None
        assert response is not None
        # A non-successful response always raises before this point.
        raise AssertionError("stream response did not produce a stream")

    async def close(self) -> None:
        """Close the HTTP client if this transport owns it."""
        if self._owns_client:
            await self._client.aclose()
